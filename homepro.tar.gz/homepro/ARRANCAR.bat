@echo off
title HomePro — Inmobiliaria SaaS
color 0A
echo.
echo  ================================
echo   HomePro Inmobiliaria SaaS
echo   Puerto 8007
echo  ================================
echo.
cd /d C:\inmobiliaria_saas
python -c "from database import init_db; init_db()"
echo  [OK] Base de datos lista
echo.
echo  Abriendo panel en 3 segundos...
timeout /t 3 /nobreak >nul
start http://localhost:8007
python -m uvicorn server:app --host 0.0.0.0 --port 8007 --reload
pause
