"""
Generador de QR para catálogos personalizados por agente
"""
import qrcode
import qrcode.image.svg
import os
import io
import base64
from PIL import Image, ImageDraw, ImageFont

QR_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "uploads", "qr")

def _ensure_dir():
    os.makedirs(QR_DIR, exist_ok=True)

def generar_qr_png(url: str, agente_codigo: str, nombre_agente: str = "") -> str:
    """Genera QR PNG y retorna base64"""
    _ensure_dir()

    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_H,
        box_size=10,
        border=4,
    )
    qr.add_data(url)
    qr.make(fit=True)

    img_qr = qr.make_image(fill_color="#1a1a2e", back_color="white").convert("RGB")

    # Canvas con branding
    ancho, alto = img_qr.size
    padding = 60
    canvas_h = alto + padding + 80
    canvas = Image.new("RGB", (ancho + padding, canvas_h), "#f8f9fa")

    # Barra superior de color
    draw = ImageDraw.Draw(canvas)
    draw.rectangle([0, 0, ancho + padding, 8], fill="#2563eb")

    # QR centrado
    x_off = padding // 2
    canvas.paste(img_qr, (x_off, 20))

    # Texto inferior
    draw.rectangle([0, alto + 25, ancho + padding, canvas_h], fill="#1e3a5f")
    draw.text((x_off + 10, alto + 35), "Escanea y encuentra tu casa", fill="white")
    if nombre_agente:
        draw.text((x_off + 10, alto + 55), f"Asesor: {nombre_agente}", fill="#93c5fd")

    buf = io.BytesIO()
    canvas.save(buf, format="PNG", dpi=(300, 300))
    buf.seek(0)

    # Guardar en disco
    path = os.path.join(QR_DIR, f"qr_{agente_codigo}.png")
    canvas.save(path, format="PNG")

    return base64.b64encode(buf.getvalue()).decode()

def generar_qr_svg(url: str) -> str:
    """Genera QR SVG y retorna string"""
    factory = qrcode.image.svg.SvgImage
    qr = qrcode.make(url, image_factory=factory)
    buf = io.BytesIO()
    qr.save(buf)
    return buf.getvalue().decode("utf-8")

def get_qr_path(agente_codigo: str) -> str:
    return os.path.join(QR_DIR, f"qr_{agente_codigo}.png")
