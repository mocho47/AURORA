"""
Calculadoras y herramientas INFONAVIT
"""

UMA_DIARIA = 113.14  # 2026
UMA_MENSUAL = UMA_DIARIA * 30.4

ETAPAS_PROCESO = [
    {"id": "contacto_inicial",   "label": "Contacto inicial",       "dias": "1-3"},
    {"id": "pre_calificacion",   "label": "Pre-calificación",        "dias": "1-2"},
    {"id": "visita_propiedad",   "label": "Visita a propiedad",      "dias": "1-7"},
    {"id": "apartado",           "label": "Apartado / enganche",     "dias": "1-3"},
    {"id": "documentacion",      "label": "Documentación completa",  "dias": "5-15"},
    {"id": "avaluo",             "label": "Avalúo",                  "dias": "7-14"},
    {"id": "dictamen",           "label": "Dictamen INFONAVIT",      "dias": "10-20"},
    {"id": "firma_escritura",    "label": "Firma de escritura",      "dias": "5-10"},
    {"id": "entrega_llaves",     "label": "Entrega de llaves",       "dias": "1-3"},
]

DOCUMENTOS_POR_TIPO = {
    "infonavit": [
        "INE vigente (ambas caras)",
        "Acta de nacimiento",
        "RFC con homoclave",
        "Comprobante de domicilio (máx 3 meses)",
        "Número de Seguro Social (NSS)",
        "Estado de cuenta subcuenta vivienda",
        "Constancia de semanas cotizadas",
        "Últimos 2 recibos de nómina",
        "CURP",
    ],
    "cofinavit": [
        "INE vigente (ambas caras)",
        "Acta de nacimiento",
        "RFC con homoclave",
        "Comprobante de domicilio",
        "NSS",
        "Constancia de semanas cotizadas",
        "Estados de cuenta bancarios (3 meses)",
        "Comprobante de ingresos adicionales",
        "Carta de autorización del banco",
        "CURP",
    ],
    "conyugal": [
        "INE vigente de ambos cónyuges",
        "Acta de matrimonio",
        "Acta de nacimiento (ambos)",
        "RFC de ambos",
        "NSS de ambos",
        "Comprobante de domicilio",
        "Constancia de semanas cotizadas (ambos)",
        "CURP de ambos",
    ],
    "corresidencial": [
        "INE de todos los corresidentes",
        "Acta de nacimiento de todos",
        "NSS de todos los participantes",
        "Comprobante parentesco (acta nacimiento / matrimonio)",
        "RFC de todos",
        "CURP de todos",
        "Comprobante de domicilio",
    ],
}

def calcular_credito_infonavit(salario_mensual: float, semanas_cotizadas: int = 52,
                                tiene_buro: bool = False) -> dict:
    vsm = salario_mensual / UMA_MENSUAL
    vsm = round(vsm, 2)

    if vsm < 1.0:
        monto_base = 0
        mensaje = "Salario menor a 1 VSM — no aplica crédito INFONAVIT"
    elif vsm < 2.0:
        monto_base = 200_000
    elif vsm < 3.0:
        monto_base = 380_000
    elif vsm < 4.0:
        monto_base = 520_000
    elif vsm < 5.0:
        monto_base = 700_000
    elif vsm < 7.0:
        monto_base = 900_000
    else:
        monto_base = 1_100_000

    # Ajuste semanas (mínimo 52 para primer crédito)
    if semanas_cotizadas < 52:
        monto_base = 0
        mensaje = f"Requiere mínimo 52 semanas cotizadas (tiene {semanas_cotizadas})"
    else:
        factor_semanas = min(semanas_cotizadas / 260, 1.0)
        ajuste = 1.0 + (factor_semanas * 0.15)
        monto_base = int(monto_base * ajuste)
        mensaje = "Cálculo estimado — puede variar por buró de crédito"

    if tiene_buro:
        monto_base = int(monto_base * 0.75)
        mensaje += " (reducido 25% por historial crediticio)"

    return {
        "salario_mensual": salario_mensual,
        "vsm": vsm,
        "semanas_cotizadas": semanas_cotizadas,
        "credito_estimado": monto_base,
        "credito_formateado": f"${monto_base:,}",
        "mensaje": mensaje,
        "tiene_buro": tiene_buro,
    }

def calcular_credito_conyugal(salario1: float, salario2: float,
                               semanas1: int = 52, semanas2: int = 52) -> dict:
    c1 = calcular_credito_infonavit(salario1, semanas1)
    c2 = calcular_credito_infonavit(salario2, semanas2)
    total = c1["credito_estimado"] + c2["credito_estimado"]
    return {
        "titular": c1,
        "conyugue": c2,
        "credito_total": total,
        "credito_formateado": f"${total:,}",
        "mensaje": "Suma de ambos créditos INFONAVIT",
    }

def calcular_cofinavit(salario_mensual: float, semanas_cotizadas: int = 52,
                        credito_bancario_adicional: float = 0) -> dict:
    infonavit = calcular_credito_infonavit(salario_mensual, semanas_cotizadas)
    capacidad_banco = salario_mensual * 40  # aprox 40 meses de salario como crédito bancario
    total = infonavit["credito_estimado"] + (credito_bancario_adicional or capacidad_banco)
    return {
        "credito_infonavit": infonavit["credito_estimado"],
        "credito_bancario_estimado": int(capacidad_banco),
        "credito_total_estimado": int(total),
        "credito_formateado": f"${int(total):,}",
        "mensaje": "COFINAVIT combina tu subcuenta INFONAVIT con crédito bancario adicional",
    }

def get_documentos(tipo_credito: str) -> list:
    return DOCUMENTOS_POR_TIPO.get(tipo_credito, DOCUMENTOS_POR_TIPO["infonavit"])

def get_etapas_proceso() -> list:
    return ETAPAS_PROCESO

def get_guia_buro() -> dict:
    return {
        "titulo": "¿Por qué INFONAVIT puede bajar tu crédito?",
        "causas": [
            "Deudas vencidas en tarjetas o préstamos personales",
            "Pagos atrasados reportados en los últimos 2 años",
            "Créditos en demanda o cobranza jurídica",
            "Más del 40% de tus ingresos comprometidos en deudas",
        ],
        "soluciones": [
            "Ponerse al corriente en pagos atrasados",
            "Carta de liquidación de deudas viejas",
            "Esperar 2 años sin movimientos negativos",
            "Solicitar aclaración directa al buró de crédito",
        ],
        "nota": "El portal Mi Cuenta INFONAVIT muestra el monto real disponible con buró incluido",
    }
