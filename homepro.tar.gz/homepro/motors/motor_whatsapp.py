"""
Notificaciones WhatsApp via Green API
"""
import os
import httpx
import asyncio

INSTANCE = os.getenv("GREEN_API_INSTANCE", "")
TOKEN = os.getenv("GREEN_API_TOKEN", "")
BASE_URL = f"https://api.green-api.com/waInstance{INSTANCE}"

async def enviar_mensaje(telefono: str, mensaje: str) -> bool:
    if not INSTANCE or not TOKEN or INSTANCE == "your_instance_here":
        print(f"[WA-MOCK] → {telefono}: {mensaje[:60]}...")
        return True

    chat_id = f"52{telefono.lstrip('0')}@c.us" if not telefono.startswith("52") else f"{telefono}@c.us"
    url = f"{BASE_URL}/sendMessage/{TOKEN}"

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.post(url, json={"chatId": chat_id, "message": mensaje})
            return r.status_code == 200
    except Exception as e:
        print(f"[WA-ERROR] {e}")
        return False

async def notificar_nuevo_prospecto(agente_tel: str, prospecto: dict, propiedad: dict = None):
    msg = (
        f"🏠 *Nuevo prospecto desde tu catálogo*\n\n"
        f"👤 Nombre: {prospecto.get('nombre')}\n"
        f"📱 Tel: {prospecto.get('telefono')}\n"
        f"💰 Crédito disponible: ${prospecto.get('credito_disponible', 0):,}\n"
    )
    if propiedad:
        msg += f"🔍 Le interesa: {propiedad.get('titulo')}\n"
    msg += "\n_Responde rápido — el primer asesor en contactar cierra más_"
    await enviar_mensaje(agente_tel, msg)

async def notificar_qr_escaneado(agente_tel: str, prospecto_nombre: str):
    msg = (
        f"👀 *Tu QR fue escaneado*\n\n"
        f"{prospecto_nombre} acaba de ver tu catálogo.\n"
        f"Revisa tu panel para ver su perfil completo."
    )
    await enviar_mensaje(agente_tel, msg)
