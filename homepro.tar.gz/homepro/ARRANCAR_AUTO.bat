@echo off
title HomePro — Arranque Automatico
color 0A
setlocal enabledelayedexpansion

echo.
echo  =========================================
echo   HomePro — Arranque Automatico con URL
echo  =========================================
echo.

cd /d C:\inmobiliaria_saas

:: ─── Inicializar base de datos ───────────────────────────
python -c "from database import init_db; init_db()" >nul 2>&1
echo  [OK] Base de datos lista

:: ─── Iniciar servidor HomePro en segundo plano ───────────
echo  [->] Iniciando servidor en puerto 8007...
start "HomePro-Server" /min python -m uvicorn server:app --host 0.0.0.0 --port 8007

:: Esperar a que levante
:ESPERAR_SERVIDOR
timeout /t 2 /nobreak >nul
powershell -Command "try{(New-Object Net.Sockets.TcpClient('localhost',8007)).Close();exit 0}catch{exit 1}" >nul 2>&1
if errorlevel 1 goto ESPERAR_SERVIDOR
echo  [OK] Servidor activo en puerto 8007

:: ─── Matar cloudflared anterior si existe ────────────────
taskkill /f /im cloudflared.exe >nul 2>&1
timeout /t 1 /nobreak >nul

:: ─── Iniciar cloudflared y capturar URL ──────────────────
echo  [->] Abriendo tunel Cloudflare...
set CF_LOG=%TEMP%\cf_homepro.log
del /f /q "%CF_LOG%" >nul 2>&1

:: cloudflared puede estar en NEXUS o en PATH
set CF_EXE=cloudflared
if exist "C:\NEXUS_v3_NEW\cloudflared.exe" set CF_EXE=C:\NEXUS_v3_NEW\cloudflared.exe
if exist "C:\cloudflared.exe" set CF_EXE=C:\cloudflared.exe

start "Cloudflare-Tunnel" /min cmd /c "%CF_EXE% tunnel --url http://localhost:8007 > "%CF_LOG%" 2>&1"

:: Esperar URL (intentos cada 2 seg, max 40 seg)
set URL=
set /a INTENTOS=0
:BUSCAR_URL
timeout /t 2 /nobreak >nul
set /a INTENTOS+=1

powershell -Command ^
  "$log = Get-Content '%CF_LOG%' -Raw -ErrorAction SilentlyContinue; " ^
  "if ($log -match 'https://([a-z0-9-]+\.trycloudflare\.com)') { $matches[0] } else { '' }" > "%TEMP%\cf_url.txt" 2>nul

set /p URL=<"%TEMP%\cf_url.txt"
set URL=!URL: =!

if "!URL!"=="" (
    if !INTENTOS! lss 20 goto BUSCAR_URL
    echo  [!] No se pudo capturar URL de Cloudflare
    goto SIN_URL
)

echo  [OK] URL capturada: !URL!

:: ─── Actualizar PUBLIC_URL en .env ───────────────────────
powershell -Command ^
  "$env = Get-Content 'C:\inmobiliaria_saas\.env' -Raw; " ^
  "$env = $env -replace 'PUBLIC_URL=.*', 'PUBLIC_URL=!URL!'; " ^
  "Set-Content 'C:\inmobiliaria_saas\.env' $env -Encoding UTF8"
echo  [OK] .env actualizado con nueva URL

:: Guardar URLs en archivo de referencia rapida
(
  echo HOMEPRO — URLs activas %date% %time%
  echo =========================================
  echo Dashboard:       !URL!/dashboard
  echo Catalogo demo:   !URL!/catalogo/DEMO01
  echo Manual asesora:  !URL!/manual/asesora
  echo Manual cliente:  !URL!/manual/cliente
) > "%USERPROFILE%\Desktop\HOMEPRO_URLS.txt"

echo  [OK] URLs guardadas en Desktop\HOMEPRO_URLS.txt

:SIN_URL
echo.
echo  =========================================
if not "!URL!"=="" (
  echo   Dashboard:      !URL!/dashboard
  echo   Catalogo:       !URL!/catalogo/DEMO01
  echo   Manual asesora: !URL!/manual/asesora
  echo   Manual cliente: !URL!/manual/cliente
) else (
  echo   Local:  http://localhost:8007
  echo   ^(sin URL publica — cloudflare no respondio^)
)
echo  =========================================
echo.

:: Abrir panel local
start http://localhost:8007

echo  Presiona cualquier tecla para cerrar esta ventana.
echo  ^(El servidor sigue corriendo en segundo plano^)
pause >nul
