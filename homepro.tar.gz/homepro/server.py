import os, json, hashlib, asyncio
from datetime import datetime
from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI, Request, Form, HTTPException, UploadFile, File
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

from database import get_conn, init_db
from motors.motor_infonavit import (calcular_credito_infonavit, calcular_credito_conyugal,
                                     calcular_cofinavit, get_documentos, get_etapas_proceso,
                                     get_guia_buro)
from motors.motor_qr import generar_qr_png, get_qr_path
from motors.motor_whatsapp import notificar_nuevo_prospecto, notificar_qr_escaneado

BASE_DIR = os.path.dirname(__file__)
app = FastAPI(title="InmobiliariaSaaS", version="1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "web", "static")), name="static")
app.mount("/uploads", StaticFiles(directory=os.path.join(BASE_DIR, "uploads")), name="uploads")
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "web", "templates"))

def hash_pwd(p): return hashlib.sha256(p.encode()).hexdigest()
def now(): return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
def row2dict(row): return dict(row) if row else None
def rows2list(rows): return [dict(r) for r in rows]

# ─── PÁGINAS PRINCIPALES ────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse(request, "login.html")

@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request, codigo: str = "DEMO01"):
    conn = get_conn()
    agente = row2dict(conn.execute("SELECT * FROM agentes WHERE codigo=?", (codigo,)).fetchone())
    conn.close()
    if not agente:
        return templates.TemplateResponse(request, "login.html", {"error": "Agente no encontrado"})
    return templates.TemplateResponse(request, "dashboard.html", {"agente": agente})

@app.get("/catalogo/{codigo}", response_class=HTMLResponse)
async def catalogo_publico(request: Request, codigo: str):
    conn = get_conn()
    agente = row2dict(conn.execute("SELECT * FROM agentes WHERE codigo=?", (codigo,)).fetchone())
    conn.close()
    if not agente:
        raise HTTPException(404, "Catálogo no encontrado")
    return templates.TemplateResponse(request, "catalogo.html", {"agente": agente})

# ─── AUTH ────────────────────────────────────────────────────────────────

@app.post("/api/login")
async def login(request: Request):
    data = await request.json()
    conn = get_conn()
    agente = row2dict(conn.execute(
        "SELECT * FROM agentes WHERE telefono=? AND password_hash=? AND activo=1",
        (data.get("telefono"), hash_pwd(data.get("password", "")))
    ).fetchone())
    conn.close()
    if not agente:
        raise HTTPException(401, "Credenciales incorrectas")
    agente.pop("password_hash", None)
    return {"ok": True, "agente": agente}

@app.post("/api/registro")
async def registro(request: Request):
    data = await request.json()
    conn = get_conn()
    import random, string
    codigo = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
    try:
        conn.execute(
            "INSERT INTO agentes (nombre,telefono,email,codigo,password_hash) VALUES (?,?,?,?,?)",
            (data["nombre"], data["telefono"], data.get("email",""), codigo, hash_pwd(data["password"]))
        )
        conn.commit()
        agente_id = conn.execute("SELECT id FROM agentes WHERE codigo=?", (codigo,)).fetchone()[0]
        conn.close()
        return {"ok": True, "codigo": codigo, "agente_id": agente_id}
    except Exception as e:
        conn.close()
        raise HTTPException(400, f"Error al registrar: {e}")

# ─── PROPIEDADES ─────────────────────────────────────────────────────────

@app.get("/api/propiedades")
async def listar_propiedades(
    agente_id: int = None, codigo_agente: str = None,
    precio_min: int = 0, precio_max: int = 9_999_999,
    municipio: str = "", tipo: str = "", estado: str = "disponible",
    recamaras: int = 0, credito_max: int = 0
):
    conn = get_conn()
    query = "SELECT * FROM propiedades WHERE 1=1"
    params = []

    if agente_id:
        query += " AND agente_id=?"; params.append(agente_id)
    elif codigo_agente:
        ag = conn.execute("SELECT id FROM agentes WHERE codigo=?", (codigo_agente,)).fetchone()
        if ag:
            query += " AND agente_id=?"; params.append(ag[0])

    if estado:
        query += " AND estado=?"; params.append(estado)
    if municipio:
        query += " AND LOWER(municipio) LIKE ?"; params.append(f"%{municipio.lower()}%")
    if tipo:
        query += " AND tipo=?"; params.append(tipo)
    if recamaras:
        query += " AND recamaras>=?"; params.append(recamaras)

    precio_min_real = precio_min
    precio_max_real = precio_max
    if credito_max and credito_max > 0:
        precio_max_real = min(precio_max, credito_max)
    query += " AND precio BETWEEN ? AND ?"; params += [precio_min_real, precio_max_real]
    query += " ORDER BY fecha_captura DESC"

    rows = rows2list(conn.execute(query, params).fetchall())
    conn.close()
    for r in rows:
        r["fotos"] = json.loads(r.get("fotos") or "[]")
    return {"ok": True, "total": len(rows), "propiedades": rows}

@app.post("/api/propiedades")
async def crear_propiedad(request: Request):
    data = await request.json()
    conn = get_conn()
    fotos = json.dumps(data.get("fotos", []))
    c = conn.execute("""
        INSERT INTO propiedades
        (agente_id,titulo,descripcion,precio,municipio,colonia,calle,
         metros_construccion,metros_terreno,recamaras,banos,estacionamientos,
         tipo,credito_infonavit,credito_cofinavit,credito_bancario,contado,estado,fotos,lat,lng)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, (
        data["agente_id"], data["titulo"], data.get("descripcion",""),
        data["precio"], data["municipio"], data.get("colonia",""), data.get("calle",""),
        data.get("metros_construccion",0), data.get("metros_terreno",0),
        data.get("recamaras",2), data.get("banos",1), data.get("estacionamientos",1),
        data.get("tipo","casa"), int(data.get("credito_infonavit",1)),
        int(data.get("credito_cofinavit",0)), int(data.get("credito_bancario",0)),
        int(data.get("contado",1)), data.get("estado","disponible"),
        fotos, data.get("lat"), data.get("lng")
    ))
    conn.commit()
    pid = c.lastrowid
    conn.close()
    return {"ok": True, "id": pid}

@app.put("/api/propiedades/{pid}")
async def actualizar_propiedad(pid: int, request: Request):
    data = await request.json()
    conn = get_conn()
    campos = []
    vals = []
    permitidos = ["titulo","descripcion","precio","municipio","colonia","calle",
                  "metros_construccion","metros_terreno","recamaras","banos",
                  "estacionamientos","tipo","estado","credito_infonavit",
                  "credito_cofinavit","credito_bancario","contado","lat","lng"]
    for k in permitidos:
        if k in data:
            campos.append(f"{k}=?")
            vals.append(data[k])
    if "fotos" in data:
        campos.append("fotos=?")
        vals.append(json.dumps(data["fotos"]))
    if not campos:
        raise HTTPException(400, "Sin campos para actualizar")
    vals.append(pid)
    conn.execute(f"UPDATE propiedades SET {','.join(campos)} WHERE id=?", vals)
    conn.commit()
    conn.close()
    return {"ok": True}

@app.delete("/api/propiedades/{pid}")
async def eliminar_propiedad(pid: int):
    conn = get_conn()
    conn.execute("DELETE FROM propiedades WHERE id=?", (pid,))
    conn.commit()
    conn.close()
    return {"ok": True}

@app.post("/api/propiedades/{pid}/vender")
async def marcar_vendida(pid: int):
    conn = get_conn()
    conn.execute("UPDATE propiedades SET estado='vendida', fecha_venta=? WHERE id=?", (now(), pid))
    conn.commit()
    conn.close()
    return {"ok": True}

# ─── PROSPECTOS ──────────────────────────────────────────────────────────

@app.get("/api/prospectos")
async def listar_prospectos(agente_id: int, estado: str = ""):
    conn = get_conn()
    q = "SELECT * FROM prospectos WHERE agente_id=?"
    p = [agente_id]
    if estado:
        q += " AND estado_proceso=?"; p.append(estado)
    q += " ORDER BY fecha_actualizacion DESC"
    rows = rows2list(conn.execute(q, p).fetchall())
    conn.close()
    return {"ok": True, "prospectos": rows}

@app.post("/api/prospectos")
async def crear_prospecto(request: Request):
    data = await request.json()

    # Buscar agente por codigo si viene del QR
    agente_id = data.get("agente_id")
    if not agente_id and data.get("codigo_agente"):
        conn = get_conn()
        ag = conn.execute("SELECT id,telefono,nombre FROM agentes WHERE codigo=?",
                          (data["codigo_agente"],)).fetchone()
        conn.close()
        if ag:
            agente_id = ag["id"]
            agente_tel = ag["telefono"]
            agente_nombre = ag["nombre"]
        else:
            raise HTTPException(404, "Agente no encontrado")
    else:
        conn = get_conn()
        ag = conn.execute("SELECT telefono,nombre FROM agentes WHERE id=?", (agente_id,)).fetchone()
        agente_tel = ag["telefono"] if ag else ""
        agente_nombre = ag["nombre"] if ag else ""
        conn.close()

    conn = get_conn()
    c = conn.execute("""
        INSERT INTO prospectos
        (agente_id,nombre,telefono,email,ocupacion,salario_mensual,credito_disponible,
         tipo_credito,municipio_interes,precio_max,notas,propiedad_interes,origen)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, (
        agente_id, data["nombre"], data["telefono"], data.get("email",""),
        data.get("ocupacion",""), data.get("salario_mensual",0),
        data.get("credito_disponible",0), data.get("tipo_credito","infonavit"),
        data.get("municipio_interes",""), data.get("precio_max",0),
        data.get("notas",""), data.get("propiedad_interes"), data.get("origen","qr")
    ))
    conn.commit()
    pid = c.lastrowid

    # Notificación
    conn.execute("INSERT INTO notificaciones (agente_id,tipo,mensaje) VALUES (?,?,?)", (
        agente_id, "nuevo_prospecto",
        f"Nuevo prospecto: {data['nombre']} — {data.get('telefono')}"
    ))
    conn.commit()
    conn.close()

    # WhatsApp async
    propiedad = None
    if data.get("propiedad_interes"):
        conn2 = get_conn()
        propiedad = row2dict(conn2.execute("SELECT titulo FROM propiedades WHERE id=?",
                                            (data["propiedad_interes"],)).fetchone())
        conn2.close()

    asyncio.create_task(notificar_nuevo_prospecto(agente_tel, data, propiedad))
    return {"ok": True, "id": pid}

@app.put("/api/prospectos/{pid}")
async def actualizar_prospecto(pid: int, request: Request):
    data = await request.json()
    conn = get_conn()
    campos = []
    vals = []
    for k in ["nombre","telefono","email","ocupacion","salario_mensual","credito_disponible",
              "tipo_credito","municipio_interes","precio_max","estado_proceso",
              "notas","propiedad_interes"]:
        if k in data:
            campos.append(f"{k}=?")
            vals.append(data[k])
    campos.append("fecha_actualizacion=?")
    vals.append(now())
    vals.append(pid)
    conn.execute(f"UPDATE prospectos SET {','.join(campos)} WHERE id=?", vals)
    conn.commit()
    conn.close()
    return {"ok": True}

# ─── PROCESOS VENTA ──────────────────────────────────────────────────────

@app.get("/api/procesos")
async def listar_procesos(agente_id: int):
    conn = get_conn()
    rows = rows2list(conn.execute("""
        SELECT pv.*, pr.nombre as prospecto_nombre, pr.telefono as prospecto_tel,
               p.titulo as propiedad_titulo, p.precio as propiedad_precio
        FROM procesos_venta pv
        JOIN prospectos pr ON pv.prospecto_id=pr.id
        JOIN propiedades p ON pv.propiedad_id=p.id
        WHERE pv.agente_id=?
        ORDER BY pv.fecha_actualizacion DESC
    """, (agente_id,)).fetchall())
    conn.close()
    for r in rows:
        r["etapas_completadas"] = json.loads(r.get("etapas_completadas") or "[]")
    return {"ok": True, "procesos": rows}

@app.post("/api/procesos")
async def crear_proceso(request: Request):
    data = await request.json()
    conn = get_conn()
    c = conn.execute("""
        INSERT INTO procesos_venta (prospecto_id,propiedad_id,agente_id,etapa)
        VALUES (?,?,?,?)
    """, (data["prospecto_id"], data["propiedad_id"], data["agente_id"],
          data.get("etapa","contacto_inicial")))
    pid = c.lastrowid

    # Crear checklist automático
    docs = get_documentos(data.get("tipo_credito","infonavit"))
    for doc in docs:
        conn.execute("INSERT INTO documentos_checklist (proceso_id,documento) VALUES (?,?)",
                     (pid, doc))
    conn.commit()
    conn.close()
    return {"ok": True, "id": pid}

@app.put("/api/procesos/{pid}/etapa")
async def avanzar_etapa(pid: int, request: Request):
    data = await request.json()
    conn = get_conn()
    proceso = row2dict(conn.execute("SELECT * FROM procesos_venta WHERE id=?", (pid,)).fetchone())
    if not proceso:
        raise HTTPException(404)
    etapas = json.loads(proceso["etapas_completadas"] or "[]")
    etapa_actual = proceso["etapa"]
    if etapa_actual not in etapas:
        etapas.append(etapa_actual)
    nueva_etapa = data.get("etapa", etapa_actual)
    if nueva_etapa == "entrega_llaves":
        fecha_cierre = now()
    else:
        fecha_cierre = proceso.get("fecha_cierre")
    conn.execute("""
        UPDATE procesos_venta SET etapa=?, etapas_completadas=?,
        notas_etapa=?, fecha_actualizacion=?, fecha_cierre=? WHERE id=?
    """, (nueva_etapa, json.dumps(etapas), data.get("notas",""),
          now(), fecha_cierre, pid))
    conn.commit()
    conn.close()
    return {"ok": True}

# ─── DOCUMENTOS CHECKLIST ────────────────────────────────────────────────

@app.get("/api/procesos/{pid}/documentos")
async def get_documentos_proceso(pid: int):
    conn = get_conn()
    rows = rows2list(conn.execute("SELECT * FROM documentos_checklist WHERE proceso_id=?", (pid,)).fetchall())
    conn.close()
    return {"ok": True, "documentos": rows}

@app.put("/api/documentos/{did}")
async def actualizar_documento(did: int, request: Request):
    data = await request.json()
    conn = get_conn()
    entregado = int(data.get("entregado", 0))
    fecha = now() if entregado else None
    conn.execute("UPDATE documentos_checklist SET entregado=?, fecha_entrega=? WHERE id=?",
                 (entregado, fecha, did))
    conn.commit()
    conn.close()
    return {"ok": True}

# ─── INFONAVIT TOOLS ─────────────────────────────────────────────────────

@app.post("/api/infonavit/calcular")
async def calcular_infonavit(request: Request):
    data = await request.json()
    tipo = data.get("tipo", "basico")
    if tipo == "conyugal":
        return calcular_credito_conyugal(
            data.get("salario1", 0), data.get("salario2", 0),
            data.get("semanas1", 52), data.get("semanas2", 52)
        )
    elif tipo == "cofinavit":
        return calcular_cofinavit(
            data.get("salario", 0), data.get("semanas", 52),
            data.get("credito_bancario", 0)
        )
    else:
        return calcular_credito_infonavit(
            data.get("salario", 0), data.get("semanas", 52),
            data.get("tiene_buro", False)
        )

@app.get("/api/infonavit/documentos")
async def docs_infonavit(tipo: str = "infonavit"):
    return {"ok": True, "documentos": get_documentos(tipo)}

@app.get("/api/infonavit/etapas")
async def etapas_proceso():
    return {"ok": True, "etapas": get_etapas_proceso()}

@app.get("/api/infonavit/buro")
async def guia_buro():
    return {"ok": True, "guia": get_guia_buro()}

# ─── QR ──────────────────────────────────────────────────────────────────

@app.get("/api/qr/{codigo}")
async def obtener_qr(codigo: str, request: Request, base_url: str = ""):
    conn = get_conn()
    agente = row2dict(conn.execute("SELECT * FROM agentes WHERE codigo=?", (codigo,)).fetchone())
    conn.close()
    if not agente:
        raise HTTPException(404, "Agente no encontrado")

    # Prefer env PUBLIC_URL, then query param, then request host
    public = os.getenv("PUBLIC_URL", "").rstrip("/")
    host = base_url.rstrip("/") if base_url else (public or str(request.base_url).rstrip("/"))
    url_catalogo = f"{host}/catalogo/{codigo}"
    qr_b64 = generar_qr_png(url_catalogo, codigo, agente["nombre"])
    return {"ok": True, "qr_base64": qr_b64, "url": url_catalogo}

@app.get("/api/qr/{codigo}/imagen")
async def descargar_qr(codigo: str, request: Request):
    conn = get_conn()
    agente = row2dict(conn.execute("SELECT * FROM agentes WHERE codigo=?", (codigo,)).fetchone())
    conn.close()
    if not agente:
        raise HTTPException(404)
    host = str(request.base_url).rstrip("/")
    url_catalogo = f"{host}/catalogo/{codigo}"
    generar_qr_png(url_catalogo, codigo, agente["nombre"])
    path = get_qr_path(codigo)
    return FileResponse(path, media_type="image/png",
                        headers={"Content-Disposition": f"attachment; filename=QR_{codigo}.png"})

# ─── NOTIFICACIONES ──────────────────────────────────────────────────────

@app.get("/api/notificaciones/{agente_id}")
async def get_notificaciones(agente_id: int):
    conn = get_conn()
    rows = rows2list(conn.execute(
        "SELECT * FROM notificaciones WHERE agente_id=? ORDER BY fecha DESC LIMIT 50",
        (agente_id,)).fetchall())
    conn.close()
    return {"ok": True, "notificaciones": rows}

@app.put("/api/notificaciones/{agente_id}/leer")
async def marcar_leidas(agente_id: int):
    conn = get_conn()
    conn.execute("UPDATE notificaciones SET leida=1 WHERE agente_id=?", (agente_id,))
    conn.commit()
    conn.close()
    return {"ok": True}

# ─── UPLOAD FOTOS ────────────────────────────────────────────────────────

@app.post("/api/upload/foto")
async def upload_foto(foto: UploadFile = File(...)):
    ext = foto.filename.split(".")[-1].lower()
    if ext not in ["jpg","jpeg","png","webp"]:
        raise HTTPException(400, "Formato no soportado")
    import uuid
    nombre = f"{uuid.uuid4().hex}.{ext}"
    ruta = os.path.join(BASE_DIR, "uploads", "fotos", nombre)
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    content = await foto.read()
    with open(ruta, "wb") as f:
        f.write(content)
    return {"ok": True, "url": f"/uploads/fotos/{nombre}"}

# ─── STATS DASHBOARD ─────────────────────────────────────────────────────

@app.get("/api/stats/{agente_id}")
async def get_stats(agente_id: int):
    conn = get_conn()
    disponibles = conn.execute("SELECT COUNT(*) FROM propiedades WHERE agente_id=? AND estado='disponible'", (agente_id,)).fetchone()[0]
    vendidas = conn.execute("SELECT COUNT(*) FROM propiedades WHERE agente_id=? AND estado='vendida'", (agente_id,)).fetchone()[0]
    total_props = conn.execute("SELECT COUNT(*) FROM propiedades WHERE agente_id=?", (agente_id,)).fetchone()[0]
    prospectos_nuevos = conn.execute("SELECT COUNT(*) FROM prospectos WHERE agente_id=? AND estado_proceso='nuevo'", (agente_id,)).fetchone()[0]
    prospectos_total = conn.execute("SELECT COUNT(*) FROM prospectos WHERE agente_id=?", (agente_id,)).fetchone()[0]
    procesos_activos = conn.execute("SELECT COUNT(*) FROM procesos_venta WHERE agente_id=? AND fecha_cierre IS NULL", (agente_id,)).fetchone()[0]
    notif_no_leidas = conn.execute("SELECT COUNT(*) FROM notificaciones WHERE agente_id=? AND leida=0", (agente_id,)).fetchone()[0]
    conn.close()
    return {
        "ok": True,
        "propiedades": {"disponibles": disponibles, "vendidas": vendidas, "total": total_props},
        "prospectos": {"nuevos": prospectos_nuevos, "total": prospectos_total},
        "procesos_activos": procesos_activos,
        "notificaciones_no_leidas": notif_no_leidas,
    }

# ─── MANUALES ────────────────────────────────────────────────────────────

@app.get("/manual/asesora", response_class=HTMLResponse)
async def manual_asesora(request: Request):
    return templates.TemplateResponse(request, "manual_asesora.html")

@app.get("/manual/cliente", response_class=HTMLResponse)
async def manual_cliente(request: Request):
    return templates.TemplateResponse(request, "manual_cliente.html")

# ─── STARTUP ─────────────────────────────────────────────────────────────

@app.on_event("startup")
async def startup():
    init_db()
    print("[OK] InmobiliariaSaaS lista en puerto", os.getenv("PORT", 8007))

if __name__ == "__main__":
    uvicorn.run("server:app", host="0.0.0.0", port=int(os.getenv("PORT", 8007)), reload=True)
