import sqlite3
import os
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(__file__), "data", "inmobiliaria.db")

def get_conn():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn

def init_db():
    conn = get_conn()
    c = conn.cursor()

    c.executescript("""
    CREATE TABLE IF NOT EXISTS agentes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL,
        telefono TEXT UNIQUE NOT NULL,
        email TEXT,
        codigo TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        municipios_favoritos TEXT DEFAULT 'Tlajomulco,Tonala',
        activo INTEGER DEFAULT 1,
        fecha_registro TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS propiedades (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        agente_id INTEGER NOT NULL,
        titulo TEXT NOT NULL,
        descripcion TEXT,
        precio INTEGER NOT NULL,
        municipio TEXT NOT NULL,
        colonia TEXT,
        calle TEXT,
        metros_construccion REAL,
        metros_terreno REAL,
        recamaras INTEGER DEFAULT 2,
        banos REAL DEFAULT 1,
        estacionamientos INTEGER DEFAULT 1,
        tipo TEXT DEFAULT 'casa',
        credito_infonavit INTEGER DEFAULT 1,
        credito_cofinavit INTEGER DEFAULT 0,
        credito_bancario INTEGER DEFAULT 0,
        contado INTEGER DEFAULT 1,
        estado TEXT DEFAULT 'disponible',
        fotos TEXT DEFAULT '[]',
        lat REAL,
        lng REAL,
        fecha_captura TEXT DEFAULT (datetime('now')),
        fecha_venta TEXT,
        FOREIGN KEY (agente_id) REFERENCES agentes(id)
    );

    CREATE TABLE IF NOT EXISTS prospectos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        agente_id INTEGER NOT NULL,
        nombre TEXT NOT NULL,
        telefono TEXT NOT NULL,
        email TEXT,
        ocupacion TEXT,
        salario_mensual INTEGER,
        credito_disponible INTEGER,
        tipo_credito TEXT DEFAULT 'infonavit',
        municipio_interes TEXT,
        precio_max INTEGER,
        estado_proceso TEXT DEFAULT 'nuevo',
        notas TEXT,
        propiedad_interes INTEGER,
        fecha_contacto TEXT DEFAULT (datetime('now')),
        fecha_actualizacion TEXT DEFAULT (datetime('now')),
        origen TEXT DEFAULT 'qr',
        FOREIGN KEY (agente_id) REFERENCES agentes(id),
        FOREIGN KEY (propiedad_interes) REFERENCES propiedades(id)
    );

    CREATE TABLE IF NOT EXISTS procesos_venta (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        prospecto_id INTEGER NOT NULL,
        propiedad_id INTEGER NOT NULL,
        agente_id INTEGER NOT NULL,
        etapa TEXT DEFAULT 'contacto_inicial',
        etapas_completadas TEXT DEFAULT '[]',
        notas_etapa TEXT,
        fecha_inicio TEXT DEFAULT (datetime('now')),
        fecha_actualizacion TEXT DEFAULT (datetime('now')),
        fecha_cierre TEXT,
        FOREIGN KEY (prospecto_id) REFERENCES prospectos(id),
        FOREIGN KEY (propiedad_id) REFERENCES propiedades(id)
    );

    CREATE TABLE IF NOT EXISTS documentos_checklist (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        proceso_id INTEGER NOT NULL,
        documento TEXT NOT NULL,
        requerido INTEGER DEFAULT 1,
        entregado INTEGER DEFAULT 0,
        fecha_entrega TEXT,
        FOREIGN KEY (proceso_id) REFERENCES procesos_venta(id)
    );

    CREATE TABLE IF NOT EXISTS notificaciones (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        agente_id INTEGER NOT NULL,
        tipo TEXT NOT NULL,
        mensaje TEXT NOT NULL,
        leida INTEGER DEFAULT 0,
        fecha TEXT DEFAULT (datetime('now')),
        FOREIGN KEY (agente_id) REFERENCES agentes(id)
    );
    """)

    # Agente demo si no existe
    c.execute("SELECT id FROM agentes WHERE codigo='DEMO01'")
    if not c.fetchone():
        import hashlib
        pwd = hashlib.sha256("demo2026".encode()).hexdigest()
        c.execute("""INSERT INTO agentes (nombre, telefono, email, codigo, password_hash, municipios_favoritos)
                     VALUES (?,?,?,?,?,?)""",
                  ("Asesora Demo", "3300000000", "demo@inmobiliaria.com", "DEMO01", pwd, "Tlajomulco,Tonala"))
        agente_id = c.lastrowid

        # Propiedades demo
        propiedades_demo = [
            (agente_id, "Casa en Coto Privado — Tlajomulco", "Amplia casa con alberca, 3 recámaras, jardín", 750000, "Tlajomulco", "San Agustín", 120, 200, 3, 2, 2, 'casa', 1),
            (agente_id, "Departamento moderno — Tonalá", "Depa nuevo estrena, 2 recámaras, elevador", 490000, "Tonala", "Centro", 75, 75, 2, 1, 1, 'departamento', 1),
            (agente_id, "Casa familiar — Tlajomulco", "3 recámaras, 2 baños, patio trasero grande", 620000, "Tlajomulco", "Valle Real", 110, 160, 3, 2, 1, 'casa', 1),
            (agente_id, "Casa económica — Tonalá", "Ideal crédito INFONAVIT, lista para entrega", 415000, "Tonala", "La Duraznera", 65, 90, 2, 1, 1, 'casa', 1),
            (agente_id, "Casa premium — Tlajomulco", "4 recámaras, roof garden, acabados de lujo", 1350000, "Tlajomulco", "Hacienda Santa Fe", 200, 300, 4, 3, 2, 'casa', 0),
        ]
        for p in propiedades_demo:
            c.execute("""INSERT INTO propiedades
                (agente_id,titulo,descripcion,precio,municipio,colonia,metros_construccion,metros_terreno,
                 recamaras,banos,estacionamientos,tipo,credito_infonavit)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""", p)

    conn.commit()
    conn.close()
    print("DB inicializada")

if __name__ == "__main__":
    init_db()
