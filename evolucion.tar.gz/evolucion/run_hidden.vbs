Set oShell = CreateObject("WScript.Shell")
Set oArgs = WScript.Arguments
If oArgs.Count > 0 Then
    oShell.Run "powershell.exe -NonInteractive -WindowStyle Hidden -File " & oArgs(0), 0, False
End If
