@echo off
title EVOLUCION
cd /d C:\evolucion
echo.
echo  EVOLUCION arrancando...
echo  http://localhost:8080
echo.
"C:\Program Files\Python312\python.exe" evolucion_server.py
pause
