"""
render_setup.py - Configura Evolucion v2 en Render AUTOMATICAMENTE
Uso: python render_setup.py <RENDER_API_KEY>
"""
import sys, json, time, hashlib, io
import urllib.request, urllib.error

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

SERVICE_NAME = "evolucion-v2"
BASE = "https://api.render.com/v1"

# Valores del .env local
ENV_VARS = {
    "GROQ_API_KEY":        "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",
    "ZAI_API_KEY":         "51e52183073542feb10d9c63d19a1731.TqakijJotGp76x5q",
    "GREEN_API_INSTANCE":  "7107622171",
    "GREEN_API_TOKEN":     "d9dc6f6f2f5944888d313b3148a93a2d85b48b59b18e4c15ba",
    "GREEN_API_SERVER":    "7107",
    "ENVIRONMENT":         "production",
    "EVOLUCION_HOSTS":     "evolucion-v2.onrender.com",
    "PORT":                "8080",
    "EVO_DB":              "/var/data/evolucion.db",
}

INSTANCE_ID = "291fb821c672ea40"
LICENSE_KEY = hashlib.sha256(f"evolucion-simplex-{INSTANCE_ID}".encode()).hexdigest()[:32]
ENV_VARS["EVOLUCION_LICENSE"] = LICENSE_KEY
ENV_VARS["EVOLUCION_INSTANCE"] = INSTANCE_ID


def call(api_key, method, path, body=None):
    url = f"{BASE}{path}"
    data = json.dumps(body).encode() if body else None
    req = urllib.request.Request(
        url,
        data=data,
        method=method,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        print(f"  ERROR {e.code}: {body[:300]}")
        return None


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    api_key = sys.argv[1].strip()
    print(f"\n{'='*55}")
    print("  EVOLUCIÓN V2 — Render Setup Automático")
    print(f"{'='*55}\n")

    # 1. Buscar el servicio
    print("[+] Buscando servicio evolucion-v2 en Render...")
    result = call(api_key, "GET", "/services?limit=20")
    if not result:
        print("  Fallo al listar servicios. Verifica tu API key.")
        sys.exit(1)

    service_id = None
    for item in result:
        svc = item.get("service", item)
        if svc.get("name") == SERVICE_NAME:
            service_id = svc["id"]
            break

    if not service_id:
        print(f"  No se encontró '{SERVICE_NAME}'. Servicios disponibles:")
        for item in result:
            svc = item.get("service", item)
            print(f"    - {svc.get('name')} ({svc.get('id')})")
        sys.exit(1)

    print(f"  OK Servicio encontrado: {service_id}\n")

    # 2. Configurar variables de entorno
    print("[+] Configurando variables de entorno...")
    env_payload = [{"key": k, "value": v} for k, v in ENV_VARS.items()]
    res = call(api_key, "PUT", f"/services/{service_id}/env-vars", env_payload)
    if res is not None:
        print(f"  OK {len(ENV_VARS)} variables configuradas")
        print(f"  KEY EVOLUCION_LICENSE: {LICENSE_KEY}")
    else:
        print("  WARN  Error configurando env vars — continúa de todas formas")

    print()

    # 3. Disparar deploy manual
    print("[+] Disparando deploy manual (rama main)...")
    deploy_res = call(api_key, "POST", f"/services/{service_id}/deploys",
                      {"clearCache": "do_not_clear"})
    if deploy_res:
        deploy_id = deploy_res.get("id", "?")
        print(f"  OK Deploy iniciado: {deploy_id}")
    else:
        print("  WARN  No se pudo disparar deploy — hazlo manual en el dashboard")

    print()

    # 4. Monitorear deploy (hasta 3 min)
    if deploy_res and deploy_res.get("id"):
        deploy_id = deploy_res["id"]
        print("[+] Monitoreando deploy (máx 3 min)...")
        for i in range(18):
            time.sleep(10)
            status_res = call(api_key, "GET", f"/services/{service_id}/deploys/{deploy_id}")
            if not status_res:
                break
            status = status_res.get("status", "unknown")
            print(f"  [{i*10+10}s] Estado: {status}")
            if status == "live":
                print("\n  OK Deploy completado — ¡servicio activo!")
                break
            elif status in ("failed", "canceled", "deactivated"):
                print(f"\n  FAIL Deploy {status}. Revisa los logs en Render.")
                break
        else:
            print("\n  TIMEOUT  Timeout — el deploy sigue corriendo, revisa el dashboard.")

    print()

    # 5. Health check
    print("[+] Verificando /health en producción...")
    time.sleep(5)
    try:
        hreq = urllib.request.Request(
            "https://evolucion-v2.onrender.com/health",
            headers={"User-Agent": "render-setup/1.0"},
        )
        with urllib.request.urlopen(hreq, timeout=20) as hr:
            hdata = json.loads(hr.read())
            print(f"  OK Health: {json.dumps(hdata, ensure_ascii=False)}")
    except Exception as e:
        print(f"  WARN  Health check: {e}")

    print(f"\n{'='*55}")
    print("  SETUP COMPLETO")
    print(f"{'='*55}")
    print(f"  URL:   https://evolucion-v2.onrender.com")
    print(f"  Admin: https://evolucion-v2.onrender.com/admin.html")
    print(f"  Nota:  Agrega el Persistent Disk en:")
    print(f"         Render → evolucion-v2 → Disks → Add Disk")
    print(f"         mountPath: /var/data  |  1 GB")
    print(f"{'='*55}\n")


if __name__ == "__main__":
    main()
