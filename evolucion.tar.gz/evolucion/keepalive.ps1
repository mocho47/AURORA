# keepalive.ps1 — Mantiene Evolucion v2 despierto en Render
# Se ejecuta cada 14 minutos via tarea programada de Windows
try {
    $r = Invoke-WebRequest -Uri "https://evolucion-v2.onrender.com/health" -TimeoutSec 30 -UseBasicParsing
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content "$PSScriptRoot\keepalive.log" "$ts OK $($r.StatusCode)"
} catch {
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content "$PSScriptRoot\keepalive.log" "$ts ERROR $_"
}
