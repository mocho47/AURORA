$response = Invoke-WebRequest -Uri "https://www.duckdns.org/update?domains=teensevolucion&token=ee417282-512c-4426-9563-c617eeef381a&ip=" -UseBasicParsing
Add-Content "C:\evolucion\duckdns.log" "$(Get-Date -Format 'yyyy-MM-dd HH:mm') — $($response.Content)"
