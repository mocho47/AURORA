import sqlite3, json
db = sqlite3.connect('evolucion.db')
c = db.cursor()
c.execute("SELECT name FROM sqlite_master WHERE type='table'")
tablas = [r[0] for r in c.fetchall()]
print("TABLAS:", tablas)
for t in tablas:
    c.execute(f"SELECT COUNT(*) FROM {t}")
    print(f"  {t}: {c.fetchone()[0]} registros")
db.close()
