import fitz, ezdxf, os

pdf_path = r"C:\Users\Administrador\Downloads\Archivos Vector.pdf"
out_dir  = r"C:\Users\Administrador\Downloads"

doc = fitz.open(pdf_path)
print(f"Paginas: {len(doc)}")

for i, page in enumerate(doc):
    dxf_path = os.path.join(out_dir, f"ArchivosVector_p{i+1}.dxf")
    dwg = ezdxf.new('R2010')
    msp = dwg.modelspace()

    paths = page.get_drawings()
    print(f"  Pagina {i+1}: {len(paths)} trazos vectoriales encontrados")

    count = 0
    for path in paths:
        for item in path.get("items", []):
            tipo = item[0]
            if tipo == "l":          # linea
                p1, p2 = item[1], item[2]
                msp.add_line((p1.x, -p1.y), (p2.x, -p2.y))
                count += 1
            elif tipo == "re":       # rectangulo
                r = item[1]
                x0, y0, x1, y1 = r.x0, -r.y0, r.x1, -r.y1
                msp.add_lwpolyline(
                    [(x0,y0),(x1,y0),(x1,y1),(x0,y1),(x0,y0)],
                    close=True
                )
                count += 1
            elif tipo == "c":        # curva bezier -> aproximar con lineas
                p1,p2,p3,p4 = item[1],item[2],item[3],item[4]
                pts = []
                for t in [k/20 for k in range(21)]:
                    u = 1-t
                    x = u**3*p1.x + 3*u**2*t*p2.x + 3*u*t**2*p3.x + t**3*p4.x
                    y = u**3*p1.y + 3*u**2*t*p2.y + 3*u*t**2*p3.y + t**3*p4.y
                    pts.append((x, -y))
                for j in range(len(pts)-1):
                    msp.add_line(pts[j], pts[j+1])
                count += 1
            elif tipo == "qu":       # curva quad bezier
                p1,p2,p3 = item[1],item[2],item[3]
                pts = []
                for t in [k/20 for k in range(21)]:
                    u = 1-t
                    x = u**2*p1.x + 2*u*t*p2.x + t**2*p3.x
                    y = u**2*p1.y + 2*u*t*p2.y + t**2*p3.y
                    pts.append((x, -y))
                for j in range(len(pts)-1):
                    msp.add_line(pts[j], pts[j+1])
                count += 1

    dwg.saveas(dxf_path)
    print(f"  -> DXF guardado: {dxf_path} ({count} elementos)")

doc.close()
print("LISTO")
