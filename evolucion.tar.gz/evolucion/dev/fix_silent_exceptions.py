import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('C:/evolucion/evolucion_server.py', encoding='utf-8') as f:
    lines = f.readlines()

changes = []

def fix_except(line_idx, old, new, desc):
    if old in lines[line_idx]:
        lines[line_idx] = lines[line_idx].replace(old, new)
        changes.append(f"L{line_idx+1}: {desc}")
        return True
    print(f"SKIP L{line_idx+1}: '{old[:40]}' not found")
    return False

# L669 - scheduler pregunta dia loop item
fix_except(668, 'except Exception: pass',
           'except Exception as e: logger.debug(f"pregunta-dia fid error: {e}")',
           'scheduler pregunta dia item')

# L969 - aptitude detection background
fix_except(968, '    except Exception:\n', '    except Exception as e: logger.debug(f"aptitud detect error: {e}")\n',
           'aptitud detection')

# L1194 - context update after streaming
fix_except(1193, '        except Exception:\n', '        except Exception as e: logger.debug(f"context update error: {e}")\n',
           'context update')

# L2282 - json parse misiones docente
fix_except(2281, 'except Exception: pass',
           'except Exception as e: logger.debug(f"misiones ctx parse: {e}")',
           'misiones docente parse')

# L2344 - json parse misiones padre
fix_except(2343, 'except Exception: pass',
           'except Exception as e: logger.debug(f"misiones padre ctx parse: {e}")',
           'misiones padre parse')

# L2706 - broadcast loop item
fix_except(2705, 'except Exception: pass',
           'except Exception as e: logger.debug(f"broadcast send error: {e}")',
           'broadcast item')

# L2722 - reporte masivo loop item
fix_except(2721, 'except Exception: pass',
           'except Exception as e: logger.debug(f"reporte send error: {e}")',
           'reporte masivo item')

# L2740 - pregunta masiva loop item
fix_except(2739, 'except Exception: pass',
           'except Exception as e: logger.debug(f"pregunta masiva send error: {e}")',
           'pregunta masiva item')

# L2861 - admin chat action execution
fix_except(2860, '    except Exception:\n', '    except Exception as e: logger.debug(f"admin chat action error: {e}")\n',
           'admin chat action')

with open('C:/evolucion/evolucion_server.py', 'w', encoding='utf-8') as f:
    f.writelines(lines)

print(f"\nFixed {len(changes)} silent exceptions:")
for c in changes:
    print(f"  {c}")
