import qrcode, os
from PIL import Image, ImageDraw, ImageFont

OUT = r"C:\Users\Administrador\Downloads\EVO_DEMO"
os.makedirs(OUT, exist_ok=True)
URL = "https://evolucion-v2.onrender.com"

items = [
    ("QR_APP.png",        f"{URL}/app",           "Entrar a Evolución"),
    ("QR_FAMILIAS.png",   f"{URL}/deck/familias", "Deck Familias"),
    ("QR_TEENS.png",      f"{URL}/deck/teens2",   "Deck Adolescentes"),
    ("QR_INVERSORES.png", f"{URL}/deck/inversores","Deck Inversores"),
    ("QR_SEP.png",        f"{URL}/deck/sep2",     "Deck SEP"),
]

for fname, url, label in items:
    qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_H, box_size=10, border=4)
    qr.add_data(url)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white").convert("RGB")
    canvas = Image.new("RGB", (img.width, img.height + 60), "white")
    canvas.paste(img, (0, 0))
    draw = ImageDraw.Draw(canvas)
    try:
        font = ImageFont.truetype("C:/Windows/Fonts/arialbd.ttf", 20)
    except:
        font = ImageFont.load_default()
    draw.text((img.width//2, img.height + 8), label, fill="#111111", font=font, anchor="mt")
    draw.text((img.width//2, img.height + 32), url, fill="#006644", font=ImageFont.load_default(), anchor="mt")
    canvas.save(os.path.join(OUT, fname))
    print(f"OK: {fname}")

print("QRs listos en:", OUT)
