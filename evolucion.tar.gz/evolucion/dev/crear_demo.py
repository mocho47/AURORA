import requests, json, qrcode, os
from PIL import Image, ImageDraw, ImageFont

BASE = "http://127.0.0.1:8080"
OUT  = r"C:\Users\Administrador\Downloads\EVO_DEMO"
os.makedirs(OUT, exist_ok=True)

URL_PUBLICA = "https://evolucion-v2.onrender.com"

# 1. Crear familia demo
r = requests.post(f"{BASE}/api/familias", json={"nombre": "Familia Demo", "codigo_acceso": "DEMO01"})
fam = r.json()
fid = fam["familia_id"]
codigo = fam["codigo_acceso"]
print(f"Familia creada: {fid} | Codigo: {codigo}")

# 2. Crear padre demo
r = requests.post(f"{BASE}/api/miembros", json={
    "familia_id": fid, "nombre": "Papa Demo", "rol": "padre",
    "edad": 40, "pin": "1234"
})
padre = r.json()
print(f"Padre: {padre['miembro_id']}")

# 3. Crear teen demo
r = requests.post(f"{BASE}/api/miembros", json={
    "familia_id": fid, "nombre": "Demo Teen", "rol": "teen",
    "edad": 15
})
teen = r.json()
print(f"Teen: {teen['miembro_id']}")

# 4. Crear misión demo
r = requests.post(f"{BASE}/api/misiones", json={
    "familia_id": fid, "titulo": "Organiza tu cuarto",
    "descripcion": "Deja todo ordenado y toma una foto", "puntos": 50,
    "asignado_a": teen["miembro_id"]
})
print(f"Mision demo creada")

# 5. Crear acuerdo demo
r = requests.post(f"{BASE}/api/acuerdos", json={
    "familia_id": fid, "teen_id": teen["miembro_id"],
    "descripcion": "Llegar antes de las 9pm los viernes",
    "recompensa": "Salida especial el fin de semana",
    "propuesto_por": "padre"
})
print(f"Acuerdo demo creado")

# 6. Generar QR app
def make_qr(url, filename, label):
    qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_H, box_size=10, border=4)
    qr.add_data(url)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white").convert("RGB")
    # Canvas con label
    canvas = Image.new("RGB", (img.width, img.height + 60), "white")
    canvas.paste(img, (0, 0))
    draw = ImageDraw.Draw(canvas)
    try:
        font = ImageFont.truetype("C:/Windows/Fonts/arialbd.ttf", 22)
    except:
        font = ImageFont.load_default()
    draw.text((img.width//2, img.height + 10), label, fill="#030308", font=font, anchor="mt")
    canvas.save(os.path.join(OUT, filename))
    print(f"QR generado: {filename}")

make_qr(f"{URL_PUBLICA}/app", "QR_APP.png", "Entrar a Evolución")
make_qr(f"{URL_PUBLICA}/deck/familias", "QR_FAMILIAS.png", "Presentación Familias")
make_qr(f"{URL_PUBLICA}/deck/teens2", "QR_TEENS.png", "Presentación Adolescentes")
make_qr(f"{URL_PUBLICA}/deck/inversores", "QR_INVERSORES.png", "Deck Inversores")
make_qr(f"{URL_PUBLICA}/deck/sep2", "QR_SEP.png", "Presentación SEP")

# 7. Guardar datos del demo
info = {
    "url_app": f"{URL_PUBLICA}/app",
    "codigo_familia": codigo,
    "familia_id": fid,
    "padre_id": padre["miembro_id"],
    "teen_id": teen["miembro_id"],
    "pin_padre": "1234",
    "decks": {
        "familias": f"{URL_PUBLICA}/deck/familias",
        "teens": f"{URL_PUBLICA}/deck/teens2",
        "sep": f"{URL_PUBLICA}/deck/sep2",
        "inversores": f"{URL_PUBLICA}/deck/inversores"
    }
}
with open(os.path.join(OUT, "demo_info.json"), "w", encoding="utf-8") as f:
    json.dump(info, f, indent=2, ensure_ascii=False)

print(f"\n=== DEMO LISTO ===")
print(f"URL: {URL_PUBLICA}/app")
print(f"Codigo familia: {codigo}")
print(f"PIN padre: 1234")
print(f"Carpeta: {OUT}")
