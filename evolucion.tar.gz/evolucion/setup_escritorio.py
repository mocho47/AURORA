"""
setup_escritorio.py
Crea icono verde Evolucion, shortcut escritorio (app mode Chrome) y carpeta unificada en Documentos.
"""
import os, sys, shutil, struct, zlib, io

DOCS = os.path.join(os.path.expanduser("~"), "Documents", "Evolucion_v2")
SRC  = r"C:\evolucion"
DESK = os.path.join(os.path.expanduser("~"), "Desktop")
CHROME = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
URL_APP    = "https://evolucion-v2.onrender.com"
URL_ADMIN  = "https://evolucion-v2.onrender.com/admin.html"
URL_LANDING = "https://evolucion-v2.onrender.com/landing.html"
ICON_PATH  = os.path.join(DOCS, "evolucion_verde.ico")


def crear_icono_verde():
    """Genera un ICO 64x64 verde con la letra E usando Pillow."""
    from PIL import Image, ImageDraw, ImageFont
    sizes = [64, 48, 32, 16]
    images = []
    for sz in sizes:
        img = Image.new("RGBA", (sz, sz), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        # Circulo verde
        margin = max(1, sz // 16)
        draw.ellipse([margin, margin, sz - margin, sz - margin],
                     fill=(34, 197, 94, 255))
        # Letra E centrada
        font_size = max(8, sz // 2)
        try:
            font = ImageFont.truetype("C:/Windows/Fonts/arialbd.ttf", font_size)
        except Exception:
            font = ImageFont.load_default()
        bbox = draw.textbbox((0, 0), "E", font=font)
        tw = bbox[2] - bbox[0]
        th = bbox[3] - bbox[1]
        draw.text(((sz - tw) // 2 - bbox[0], (sz - th) // 2 - bbox[1]),
                  "E", font=font, fill=(255, 255, 255, 255))
        images.append(img)

    buf = io.BytesIO()
    images[0].save(buf, format="ICO",
                   sizes=[(s, s) for s in sizes],
                   append_images=images[1:])
    os.makedirs(os.path.dirname(ICON_PATH), exist_ok=True)
    with open(ICON_PATH, "wb") as f:
        f.write(buf.getvalue())
    print(f"  Icono: {ICON_PATH}")


def crear_shortcut(nombre, url, icon=None):
    """Crea .lnk en escritorio con Chrome app mode."""
    import winreg
    try:
        import win32com.client as wc
        shell = wc.Dispatch("WScript.Shell")
        lnk_path = os.path.join(DESK, f"{nombre}.lnk")
        sc = shell.CreateShortcut(lnk_path)
        sc.TargetPath = CHROME
        sc.Arguments = f'--app="{url}" --app-id=evolucion'
        sc.WorkingDirectory = os.path.dirname(CHROME)
        sc.Description = nombre
        if icon:
            sc.IconLocation = icon
        sc.save()
        print(f"  Shortcut: {lnk_path}")
        return True
    except ImportError:
        # Fallback: usar PowerShell
        icon_str = f", 0" if not icon else f",0"
        ps = f"""
$ws = New-Object -ComObject WScript.Shell
$sc = $ws.CreateShortcut('{os.path.join(DESK, nombre)}.lnk')
$sc.TargetPath = '{CHROME}'
$sc.Arguments = '--app="{url}" --app-id=evolucion'
$sc.WorkingDirectory = '{os.path.dirname(CHROME)}'
$sc.Description = '{nombre}'
""" + (f"$sc.IconLocation = '{icon}'\n" if icon else "") + "$sc.Save()"
        import subprocess
        subprocess.run(["powershell", "-Command", ps], capture_output=True)
        print(f"  Shortcut via PS: {os.path.join(DESK, nombre)}.lnk")
        return True


def crear_estructura_docs():
    """Crea carpeta unificada en Documentos con todo el proyecto."""
    carpetas = {
        "1_Servidor":        ["evolucion_server.py", "evolucion_reporte.py",
                               "requirements.txt", "render.yaml", "Procfile",
                               "railway.toml", "LICENCIA.md"],
        "2_Paneles_Web":     ["evolucion.html", "admin.html", "maestro.html",
                               "landing.html", "privacidad.html", "terminos.html",
                               "nosotros.html", "panel_escolar.html", "jorge.html"],
        "3_Manuales":        None,   # carpeta completa
        "4_Presentaciones":  None,   # carpeta completa
        "5_Config":          [".env", "render_setup.py", "arrancar.ps1"],
    }

    os.makedirs(DOCS, exist_ok=True)

    for carpeta, archivos in carpetas.items():
        dest = os.path.join(DOCS, carpeta)
        os.makedirs(dest, exist_ok=True)

        if archivos is None:
            # Copiar carpeta completa
            nombre_src = carpeta.split("_", 1)[1].lower()
            # mapear a nombre real
            mapa = {
                "manuales": "manuales",
                "presentaciones": "presentaciones",
            }
            src_folder_name = mapa.get(nombre_src, nombre_src)
            src_path = os.path.join(SRC, src_folder_name)
            if os.path.isdir(src_path):
                for item in os.listdir(src_path):
                    s = os.path.join(src_path, item)
                    d = os.path.join(dest, item)
                    if os.path.isfile(s):
                        shutil.copy2(s, d)
                print(f"  {carpeta}/ copiado")
        else:
            for fname in archivos:
                src_file = os.path.join(SRC, fname)
                if os.path.exists(src_file):
                    shutil.copy2(src_file, os.path.join(dest, fname))
            print(f"  {carpeta}/ copiado")

    # PDFs sueltos en raiz
    pdfs_src = os.path.join(SRC, "PDFs")
    pdfs_dest = os.path.join(DOCS, "4_Presentaciones", "PDFs_extra")
    if os.path.isdir(pdfs_src) and os.listdir(pdfs_src):
        os.makedirs(pdfs_dest, exist_ok=True)
        for f in os.listdir(pdfs_src):
            shutil.copy2(os.path.join(pdfs_src, f), os.path.join(pdfs_dest, f))


def crear_accesos_html():
    """Crea un index.html de accesos rápidos en la carpeta del proyecto."""
    html = f"""<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8">
<title>Evolución v2 — Accesos</title>
<style>
body{{font-family:sans-serif;max-width:600px;margin:60px auto;background:#f0fdf4}}
h1{{color:#16a34a}}
.btn{{display:block;padding:14px 20px;margin:10px 0;background:#22c55e;color:#fff;
text-decoration:none;border-radius:10px;font-size:1.1em;font-weight:bold}}
.btn:hover{{background:#16a34a}}
.admin{{background:#7c3aed}}
.admin:hover{{background:#6d28d9}}
.land{{background:#0ea5e9}}
.land:hover{{background:#0284c7}}
small{{color:#666}}
</style></head>
<body>
<h1>Evolución v2</h1>
<p><small>Plataforma de desarrollo humano adolescente — SIMPLEX</small></p>
<a href="{URL_APP}" target="_blank" class="btn">App (Teens / Padres)</a>
<a href="{URL_APP}/maestro.html" target="_blank" class="btn">Panel Maestros</a>
<a href="{URL_ADMIN}" target="_blank" class="btn admin">Panel Admin</a>
<a href="{URL_LANDING}" target="_blank" class="btn land">Landing Page</a>
<hr>
<p><small>Servidor: {URL_APP}<br>
Admin key: 5d3cd4066d0b9b0b9564<br>
Demo: codigo DEMO01 | PIN 1234</small></p>
</body></html>"""
    idx = os.path.join(DOCS, "ACCESOS_RAPIDOS.html")
    with open(idx, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"  Accesos rapidos: {idx}")


def main():
    print("\n" + "="*50)
    print("  EVOLUCION V2 — Setup Escritorio + Documentos")
    print("="*50 + "\n")

    print("[1] Creando icono verde...")
    crear_icono_verde()

    print("\n[2] Creando shortcuts en escritorio...")
    crear_shortcut("Evolucion", URL_APP, ICON_PATH)
    crear_shortcut("Evolucion Admin", URL_ADMIN, ICON_PATH)

    print("\n[3] Organizando carpeta en Documentos...")
    crear_estructura_docs()

    print("\n[4] Creando accesos rapidos HTML...")
    crear_accesos_html()

    print(f"\n{'='*50}")
    print("  LISTO")
    print(f"{'='*50}")
    print(f"  Escritorio:  Evolucion.lnk (app mode Chrome)")
    print(f"  Documentos:  {DOCS}")
    print(f"  Accesos:     {DOCS}\\ACCESOS_RAPIDOS.html")
    print(f"{'='*50}\n")


if __name__ == "__main__":
    main()
