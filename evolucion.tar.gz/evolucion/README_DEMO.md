# Evolución v2 — Demo para desarrollador

## ¿Qué es?
Plataforma de bienestar emocional para adolescentes. Conecta teens, padres y maestros con IA.
Deploy: https://evolucion-v2.onrender.com

## Roles
- **Teen** — chat IA, streak, logros, módulos cognitivos
- **Padre/Madre** — semáforo familiar, misiones, SOS, reporte PDF
- **Maestro** — heatmap de clase, expediente, protocolo intervención
- **Admin** — gestión de escuelas, usuarios, métricas

## Stack
- Python 3.12 + FastAPI + SQLite (migración Supabase pendiente)
- Groq API (llama-3.1-8b-instant) para IA
- Green API para WhatsApp
- Deploy: Render.com (render.yaml incluido)

## Arrancar local

### 1. Instalar dependencias
```bash
pip install -r requirements.txt
```

### 2. Configurar .env
```
GROQ_API_KEY=tu_clave_groq
GREEN_API_INSTANCE=tu_instancia
GREEN_API_TOKEN=tu_token
GREEN_API_SERVER=7107
ADMIN_KEY=clave_admin
APP_SECRET=cualquier_string_largo
PORT=8080
```

### 3. Correr
```bash
python evolucion_server.py
```
Abre: http://localhost:8080

## Código de familia demo
El admin crea familias desde `/admin`. El código generado lo usa el teen para entrar.

## Archivos clave
| Archivo | Descripción |
|---------|-------------|
| `evolucion_server.py` | Servidor completo (~4500 líneas) |
| `evolucion.html` | UI principal (teen + padre + maestro) |
| `admin.html` | Panel de administración |
| `maestro.html` | Panel del maestro |
| `render.yaml` | Config deploy Render |
| `manuales/` | Documentación completa |

## Contribuir
Coordinarse con Anuar Milan — milanmontellanoanuar@gmail.com
