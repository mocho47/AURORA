Start-Sleep -Seconds 10

$pyExe = "C:\Program Files\Python312\python.exe"
$ngrok = "C:\Users\Administrador\AppData\Local\Microsoft\WinGet\Links\ngrok.exe"

# ── Evolución v2 (puerto 8080) ────────────────────────────────────────────────
Start-Process -FilePath $pyExe `
    -ArgumentList "evolucion_server.py" `
    -WorkingDirectory "C:\evolucion" `
    -WindowStyle Hidden `
    -RedirectStandardOutput "C:\evolucion\evo.log" `
    -RedirectStandardError  "C:\evolucion\evo_err.log"

# ── NEXUS v4 (puerto 8090) ───────────────────────────────────────────────────
Start-Process -FilePath $pyExe `
    -ArgumentList "-m uvicorn nexus_v4_server:app --host 0.0.0.0 --port 8090" `
    -WorkingDirectory "C:\nexus_v4" `
    -WindowStyle Hidden `
    -RedirectStandardOutput "C:\nexus_v4\nexus_v4.log" `
    -RedirectStandardError  "C:\nexus_v4\nexus_v4_err.log"

Start-Sleep -Seconds 10

# ── ngrok → Evolución (dominio fijo) ─────────────────────────────────────────
Start-Process -FilePath $ngrok -ArgumentList "start evolucion" -WindowStyle Hidden
