@echo off
title Milens Bot — Instalador
echo.
echo ============================================================
echo    MILENS BOT — Asistente Publicitario
echo    Instalacion automatica
echo ============================================================
echo.

cd /d C:\milens_bot

echo [1/3] Instalando dependencias...
pip install fastapi uvicorn python-dotenv httpx groq openai -q
if errorlevel 1 (
    echo ERROR: pip no disponible. Verifica que Python este instalado.
    pause
    exit /b 1
)
echo     Dependencias OK

echo [2/3] Iniciando servidor en puerto 8011...
start "" "http://localhost:8011"

echo [3/3] Abriendo Milens Bot en el navegador...
echo.
echo ============================================================
echo    Bot activo en: http://localhost:8011
echo    Para WhatsApp: configura GREEN_INSTANCE en .env
echo    Cierra esta ventana para detener el bot
echo ============================================================
echo.

python -m uvicorn server:app --host 0.0.0.0 --port 8011
pause
