"""
Milens Bot — Asistente Publicitario
Bot de diseño para Creaciones Milens
Puerto 8011
"""
import os, asyncio, logging, base64, httpx, json
from pathlib import Path
from datetime import datetime
from dotenv import load_dotenv
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from openai import OpenAI

load_dotenv(Path(__file__).parent / ".env")
logging.basicConfig(level=logging.INFO)
log = logging.getLogger("MILENS")

GROQ_KEY = os.getenv("GROQ_API_KEY", "")
ZAI_KEY  = os.getenv("ZAI_API_KEY", "")
GREEN_INSTANCE = os.getenv("GREEN_INSTANCE", "")
GREEN_TOKEN    = os.getenv("GREEN_TOKEN", "")
GREEN_SERVER   = os.getenv("GREEN_SERVER", "7103")
MILENS_PHONE   = os.getenv("MILENS_PHONE", "3300000000")

GREEN_BASE = f"https://{GREEN_SERVER}.api.greenapi.com/waInstance{GREEN_INSTANCE}" if GREEN_INSTANCE else ""

# ── System prompt Milens ──────────────────────────────────────────────────────
SYSTEM_MILENS = """Eres el asistente publicitario de Creaciones Milens, negocio de corte láser en Guadalajara.

PRODUCTOS MILENS (corte láser y acrílico):
• Cajas y joyeros MDF
• Portarretratos con grabado
• Letras decorativas y nombres
• Llaveros personalizados
• Alcancías y figuras decorativas
• Centros de mesa y bodas
• Piezas de acrílico iluminado

ESTILO DE MARCA: Rústico-elegante. Tonos madera natural, crema, dorado. Complementos en negro o blanco.
SLOGAN SUGERIDO: "Cada pieza, única como tú."

TU FUNCIÓN: Ayudar a crear anuncios publicitarios listos para usar.

CUANDO RECIBAS UNA SOLICITUD DE ANUNCIO, responde con:
1. **DESCRIPCIÓN VISUAL**: Describe la imagen exacta que se debe crear (fondo, colores, elementos, tipografía, disposición)
2. **TEXTO DEL ANUNCIO**: El copy exacto que debe llevar la imagen
3. **ESPECIFICACIONES TÉCNICAS**: Dimensiones y DPI según el destino
4. **PROMPT PARA IA**: Un prompt en inglés listo para pegar en Midjourney/DALL-E/Flux para generar la imagen base

FORMATOS ESTÁNDAR MILENS:
• Post Instagram/Facebook: 1080x1080 px, 72 DPI
• Historia: 1080x1920 px, 72 DPI
• Flyer impresión: 21x28 cm, 300 DPI (carta)
• Banner WhatsApp: 1280x720 px, 72 DPI

REGLAS:
- Responde en español, tono amigable.
- Si no especifica el producto, pregunta qué quiere anunciar.
- Si no especifica el destino, pregunta si es para redes o imprimir.
- Siempre incluye el número de WhatsApp o la frase "Milens GDL" en el anuncio.
- Genera prompts de imagen en inglés, muy descriptivos.
"""

# ── IA ────────────────────────────────────────────────────────────────────────
async def ask_ai(user_msg: str, history: list[dict] | None = None) -> str:
    messages = [{"role": "system", "content": SYSTEM_MILENS}]
    if history:
        messages.extend(history[-8:])
    messages.append({"role": "user", "content": user_msg})

    if GROQ_KEY:
        try:
            from groq import Groq
            loop = asyncio.get_event_loop()
            client = Groq(api_key=GROQ_KEY, timeout=25)
            resp = await loop.run_in_executor(None, lambda: client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=messages, max_tokens=1024, temperature=0.8
            ))
            return resp.choices[0].message.content
        except Exception as e:
            log.warning("Groq fallo: %s", e)

    if ZAI_KEY:
        try:
            loop = asyncio.get_event_loop()
            client = OpenAI(api_key=ZAI_KEY, base_url="https://open.bigmodel.cn/api/paas/v4/", timeout=25)
            resp = await loop.run_in_executor(None, lambda: client.chat.completions.create(
                model="glm-4-flash", messages=messages, max_tokens=1024, temperature=0.8
            ))
            return resp.choices[0].message.content
        except Exception as e:
            log.warning("Z.ai fallo: %s", e)

    return "En este momento no tengo conexión a IA. Intenta en unos minutos."

# ── Sesiones ──────────────────────────────────────────────────────────────────
_sessions: dict[str, list[dict]] = {}

def _history(phone: str) -> list[dict]:
    return _sessions.setdefault(phone, [])

def _append(phone: str, role: str, content: str):
    h = _sessions.setdefault(phone, [])
    h.append({"role": role, "content": content})
    if len(h) > 20:
        _sessions[phone] = h[-20:]

# ── WhatsApp (Green API) ──────────────────────────────────────────────────────
async def send_wa(to: str, text: str):
    if not GREEN_INSTANCE:
        return
    async with httpx.AsyncClient(timeout=15) as c:
        try:
            await c.post(f"{GREEN_BASE}/sendMessage/{GREEN_TOKEN}",
                         json={"chatId": f"{to}@c.us", "message": text})
        except Exception as e:
            log.error("WA error: %s", e)

# ── App ───────────────────────────────────────────────────────────────────────
app = FastAPI(title="Milens Bot")

@app.post("/wa/webhook")
async def wa_webhook(request: Request):
    try:
        data = await request.json()
    except Exception:
        return JSONResponse({"ok": False})

    if data.get("typeWebhook") != "incomingMessageReceived":
        return JSONResponse({"ok": True})

    sender = data.get("senderData", {}).get("sender", "").replace("@c.us", "")
    text   = data.get("messageData", {}).get("textMessageData", {}).get("textMessage", "").strip()

    if not text or not sender:
        return JSONResponse({"ok": True})

    log.info("WA de %s: %s", sender, text[:80])
    _append(sender, "user", text)
    reply = await ask_ai(text, _history(sender))
    _append(sender, "assistant", reply)
    await send_wa(sender, reply)
    return JSONResponse({"ok": True})

@app.post("/api/chat")
async def api_chat(request: Request):
    body = await request.json()
    msg  = body.get("mensaje", "")
    tel  = body.get("sesion", "web")
    _append(tel, "user", msg)
    reply = await ask_ai(msg, _history(tel))
    _append(tel, "assistant", reply)
    return JSONResponse({"respuesta": reply})

@app.get("/", response_class=HTMLResponse)
async def index():
    return HTMLResponse("""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Milens — Asistente Publicitario</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI',sans-serif;background:#1a0f05;color:#f5ede0;min-height:100vh}
header{background:linear-gradient(135deg,#3d1f00,#6b3a1f);padding:24px;text-align:center}
header h1{font-size:1.8rem;color:#d4a96a}
header p{color:#c4a882;margin-top:4px}
.chat-wrap{max-width:700px;margin:30px auto;padding:0 16px}
#msgs{height:420px;overflow-y:auto;background:#110900;border:1px solid #3d2a15;border-radius:12px;padding:16px;margin-bottom:16px}
.msg-user{text-align:right;margin:8px 0}
.msg-user span{background:#6b3a1f;color:#f5ede0;padding:8px 14px;border-radius:18px 18px 4px 18px;display:inline-block;max-width:80%;font-size:.9rem}
.msg-bot{text-align:left;margin:8px 0}
.msg-bot span{background:#2a1a08;border:1px solid #3d2a15;color:#e8d5b0;padding:8px 14px;border-radius:18px 18px 18px 4px;display:inline-block;max-width:85%;font-size:.9rem;white-space:pre-wrap}
.input-row{display:flex;gap:10px}
input{flex:1;background:#110900;border:1px solid #3d2a15;color:#f5ede0;padding:12px;border-radius:8px;outline:none;font-size:.95rem}
button{background:#d4a96a;color:#1a0f05;border:none;padding:12px 24px;border-radius:8px;font-weight:bold;cursor:pointer;font-size:.95rem}
button:hover{background:#c4904a}
.sugerencias{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px}
.sug{background:#2a1a08;border:1px solid #3d2a15;color:#d4a96a;padding:6px 12px;border-radius:20px;font-size:.8rem;cursor:pointer}
.sug:hover{background:#3d2a15}
</style>
</head>
<body>
<header>
  <h1>✨ Milens — Asistente Publicitario</h1>
  <p>Creaciones en MDF y acrílico • Corte láser Guadalajara</p>
</header>
<div class="chat-wrap">
  <div class="sugerencias">
    <div class="sug" onclick="send('Quiero un anuncio para Instagram de cajas de madera personalizadas')">Anuncio caja MDF</div>
    <div class="sug" onclick="send('Crea un flyer para imprimir de llaveros personalizados')">Flyer llaveros</div>
    <div class="sug" onclick="send('Necesito una historia de Instagram para centros de mesa de boda')">Historia boda</div>
    <div class="sug" onclick="send('Anuncio de letra decorativa grande para sala')">Letras decorativas</div>
  </div>
  <div id="msgs">
    <div class="msg-bot"><span>Hola! Soy tu asistente de diseño para Milens 🌿
Dime qué producto quieres anunciar y para qué plataforma, y te doy la descripción visual, el copy y el prompt listo para generar la imagen.</span></div>
  </div>
  <div class="input-row">
    <input id="inp" type="text" placeholder="Ej: Anuncio de portarretratos con grabado para mamá...">
    <button onclick="send()">Crear</button>
  </div>
</div>
<script>
const msgs = document.getElementById('msgs');
const inp  = document.getElementById('inp');
let sesion = 'user_' + Date.now();

function addMsg(role, txt) {
  const d = document.createElement('div');
  d.className = role === 'user' ? 'msg-user' : 'msg-bot';
  const s = document.createElement('span');
  s.textContent = txt;
  d.appendChild(s);
  msgs.appendChild(d);
  msgs.scrollTop = msgs.scrollHeight;
}

async function send(texto) {
  const msg = texto || inp.value.trim();
  if (!msg) return;
  inp.value = '';
  addMsg('user', msg);
  addMsg('bot', '...');
  try {
    const r = await fetch('/api/chat', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({mensaje: msg, sesion})
    });
    const d = await r.json();
    msgs.lastChild.querySelector('span').textContent = d.respuesta;
  } catch(e) {
    msgs.lastChild.querySelector('span').textContent = 'Error de conexión';
  }
  msgs.scrollTop = msgs.scrollHeight;
}

inp.addEventListener('keydown', e => { if (e.key === 'Enter') send(); });
</script>
</body>
</html>""")

@app.get("/health")
async def health():
    return {"status": "ok", "bot": "Milens", "ts": datetime.now().isoformat()}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("server:app", host="0.0.0.0", port=8011, reload=False)
