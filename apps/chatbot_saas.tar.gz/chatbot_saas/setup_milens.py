from pathlib import Path

CLIENTES_DIR = Path('C:/chatbot_saas/clientes')
cid, nombre = 2, 'Creaciones_Milens'
folder = CLIENTES_DIR / f'{cid:04d}_{nombre.lower()[:20]}'
for sub in ('productos', 'logo', 'archivos'):
    (folder / sub).mkdir(parents=True, exist_ok=True)

catalogo = """# Catalogo Creaciones Milens
# Formato: Nombre | Precio | Descripcion

Llavero MDF personalizado | desde $35 c/u (min 10 pzas) | Grabado laser, cualquier diseno
Caja MDF con tapa grabada | desde $120 c/u | Varios tamanos disponibles
Stickers personalizados | desde $8 c/u (min 50 pzas) | Vinyl de alta calidad
Grabado en acrilico | Cotizacion segun tamano | Colores disponibles
Senaletica hotelera | Cotizacion segun proyecto | MDF y acrilico
Posavasos MDF set x4 | desde $80 el set | Grabado personalizado
Tabla de servicio grabada | desde $180 c/u | Madera natural
Porta menu restaurante | desde $95 c/u | Con grabado de logo
"""

(folder / 'catalogo.txt').write_text(catalogo, encoding='utf-8')
print(f'OK: {folder}')
