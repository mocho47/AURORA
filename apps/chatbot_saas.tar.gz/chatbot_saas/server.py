"""
CHATBOT WA SAAS — by Simplex
Servicio multi-tenant de chatbots WhatsApp con IA
Puerto: 8005
"""
import os, json, sqlite3, asyncio, logging
from datetime import datetime
from pathlib import Path
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request, Form, Depends
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import Optional
import httpx

# ── Config ────────────────────────────────────────────────────────────────────
BASE_DIR   = Path(__file__).parent
DB_PATH    = BASE_DIR / "chatbot.db"
TEMPLATES  = BASE_DIR / "templates"
PORT       = int(os.getenv("PORT", 8005))
GROQ_KEY   = os.getenv("GROQ_API_KEY", "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")
GROQ_MODEL = "llama-3.1-8b-instant"
ADMIN_KEY       = os.getenv("ADMIN_KEY", "simplex2026")
MP_ACCESS_TOKEN = os.getenv("MP_ACCESS_TOKEN", "")
DOMINIO_PUBLICO = os.getenv("DOMINIO_PUBLICO", "https://enrique-slaty-afton.ngrok-free.dev")
SENDER_INSTANCE = os.getenv("SENDER_INSTANCE", "")   # WA propio de Anuar para enviar links
SENDER_TOKEN    = os.getenv("SENDER_TOKEN", "")
SENDER_SERVER   = os.getenv("SENDER_SERVER", "7107")
META_VERIFY_TOKEN = os.getenv("META_VERIFY_TOKEN", "simplex_meta_2026")
META_APP_SECRET   = os.getenv("META_APP_SECRET", "")
CLIENTES_DIR    = BASE_DIR / "clientes"
CLIENTES_DIR.mkdir(exist_ok=True)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("chatbot_saas")

def carpeta_cliente(cid: int, nombre: str) -> Path:
    slug = nombre.lower().replace(" ", "_")[:20]
    folder = CLIENTES_DIR / f"{cid:04d}_{slug}"
    for sub in ("productos", "logo", "archivos"):
        (folder / sub).mkdir(parents=True, exist_ok=True)
    catalogo = folder / "catalogo.txt"
    if not catalogo.exists():
        catalogo.write_text(
            "# CATÁLOGO — edita este archivo con tus productos\n"
            "# Formato: Nombre | Precio | Descripción\n",
            encoding="utf-8"
        )
    return folder

def carpeta_de(cid: int) -> Optional[Path]:
    matches = [d for d in CLIENTES_DIR.iterdir() if d.name.startswith(f"{cid:04d}_")]
    return matches[0] if matches else None

def leer_catalogo_txt(cid: int, nombre: str = "") -> str:
    folder = carpeta_de(cid)
    if not folder:
        return ""
    cat = folder / "catalogo.txt"
    if not cat.exists():
        return ""
    lines = [l.strip() for l in cat.read_text(encoding="utf-8").splitlines()
             if l.strip() and not l.strip().startswith("#")]
    return "\n".join(lines)

async def sincronizar_catalogo_wa(cid: int, instance: str, token: str, server: str) -> dict:
    """Obtiene catálogo de WhatsApp Business y actualiza catalogo.txt del cliente."""
    base = green_base(instance, server)
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            r = await client.get(f"{base}/getProductsFromList/{token}")
            if r.status_code != 200:
                return {"ok": False, "msg": f"Green API status {r.status_code}"}
            data = r.json()
            products = data.get("products", [])
            if not products:
                return {"ok": False, "msg": "Sin productos en catálogo WA o plan no soportado"}
            lines = ["# Catálogo sincronizado desde WhatsApp Business", "# Formato: Nombre | Precio | Descripción", ""]
            for p in products:
                name  = p.get("name", "Producto")
                price = p.get("price", "")
                desc  = p.get("description", "")
                currency = p.get("currency", "MXN")
                price_fmt = f"${price} {currency}" if price else "Consultar precio"
                lines.append(f"{name} | {price_fmt} | {desc}")
            db = get_db()
            c = db.execute("SELECT nombre_negocio FROM clientes WHERE id=?", (cid,)).fetchone()
            db.close()
            nombre = c["nombre_negocio"] if c else ""
            folder = carpeta_de(cid) or carpeta_cliente(cid, nombre)
            (folder / "catalogo.txt").write_text("\n".join(lines), encoding="utf-8")
            return {"ok": True, "productos": len(products), "catalogo": "\n".join(lines)}
    except Exception as e:
        return {"ok": False, "msg": str(e)}

# ── Base de datos ──────────────────────────────────────────────────────────────
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS clientes (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre_negocio  TEXT NOT NULL,
            nombre_contacto TEXT,
            telefono        TEXT,
            email           TEXT,
            green_instance  TEXT NOT NULL,
            green_token     TEXT NOT NULL,
            green_server    TEXT NOT NULL DEFAULT '7107',
            plan            TEXT DEFAULT 'basico',
            activo          INTEGER DEFAULT 1,
            fecha_inicio    TEXT DEFAULT (date('now')),
            fecha_vencimiento TEXT DEFAULT (date('now','+15 days')),
            es_demo         INTEGER DEFAULT 1,
            precio_mensual  INTEGER DEFAULT 900,
            notas           TEXT
        );
        CREATE TABLE IF NOT EXISTS config_bot (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente_id      INTEGER UNIQUE REFERENCES clientes(id),
            nombre_bot      TEXT DEFAULT 'Asistente',
            saludo          TEXT DEFAULT '¡Hola! ¿En qué te puedo ayudar?',
            descripcion     TEXT,
            productos       TEXT DEFAULT '[]',
            faq             TEXT DEFAULT '[]',
            horario         TEXT DEFAULT 'Lun-Sáb 9am-7pm',
            limite_diario   INTEGER DEFAULT 200,
            prompt_extra    TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS mensajes (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente_id  INTEGER REFERENCES clientes(id),
            chat_id     TEXT,
            direccion   TEXT,
            texto       TEXT,
            timestamp   TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS conversaciones (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente_id      INTEGER REFERENCES clientes(id),
            chat_id         TEXT,
            historial       TEXT DEFAULT '[]',
            ultima_actividad TEXT DEFAULT (datetime('now')),
            UNIQUE(cliente_id, chat_id)
        );
        CREATE TABLE IF NOT EXISTS signups (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre_negocio   TEXT NOT NULL,
            nombre_contacto  TEXT,
            telefono         TEXT,
            email            TEXT,
            plan             TEXT DEFAULT 'basico',
            precio_mensual   INTEGER DEFAULT 150,
            estado           TEXT DEFAULT 'pendiente_pago',
            mp_preference_id TEXT,
            mp_payment_id    TEXT,
            setup_token      TEXT UNIQUE,
            cliente_id       INTEGER,
            fecha_creacion   TEXT DEFAULT (datetime('now')),
            fecha_pago       TEXT
        );
        CREATE TABLE IF NOT EXISTS pedidos (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente_id     INTEGER REFERENCES clientes(id),
            chat_id        TEXT,
            nombre_cliente TEXT,
            producto       TEXT,
            cantidad       TEXT,
            fecha_entrega  TEXT,
            notas          TEXT,
            estado         TEXT DEFAULT 'nuevo',
            monto          REAL DEFAULT 0,
            mp_link        TEXT,
            mp_pagado      INTEGER DEFAULT 0,
            timestamp      TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS citas (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente_id     INTEGER REFERENCES clientes(id),
            chat_id        TEXT,
            nombre_cliente TEXT,
            servicio       TEXT,
            fecha          TEXT,
            hora           TEXT,
            notas          TEXT,
            estado         TEXT DEFAULT 'pendiente',
            recordatorio   INTEGER DEFAULT 0,
            timestamp      TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS leads (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente_id     INTEGER REFERENCES clientes(id),
            chat_id        TEXT,
            nombre_cliente TEXT,
            interes        TEXT,
            timestamp      TEXT DEFAULT (datetime('now'))
        );
        """)
        # Migración segura — agrega columnas nuevas si no existen
        for tbl, col, definition in [
            ("clientes",   "fecha_vencimiento",      "TEXT DEFAULT (date('now','+15 days'))"),
            ("clientes",   "es_demo",                "INTEGER DEFAULT 1"),
            ("clientes",   "fb_page_id",             "TEXT DEFAULT ''"),
            ("clientes",   "fb_page_token",          "TEXT DEFAULT ''"),
            ("clientes",   "ig_account_id",          "TEXT DEFAULT ''"),
            ("clientes",   "ig_token",               "TEXT DEFAULT ''"),
            ("config_bot", "telefono_notificaciones", "TEXT DEFAULT ''"),
            ("config_bot", "permite_pedidos",         "INTEGER DEFAULT 1"),
            ("config_bot", "permite_citas",           "INTEGER DEFAULT 0"),
            ("config_bot", "servicios",               "TEXT DEFAULT '[]'"),
            ("config_bot", "horarios_cita",           "TEXT DEFAULT '[]'"),
            ("config_bot", "fb_activo",               "INTEGER DEFAULT 0"),
            ("config_bot", "ig_activo",               "INTEGER DEFAULT 0"),
        ]:
            try:
                db.execute(f"ALTER TABLE {tbl} ADD COLUMN {col} {definition}")
            except Exception:
                pass
        db.commit()

# ── App ───────────────────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    asyncio.create_task(tarea_recordatorios())
    log.info(f"Chatbot SaaS iniciado — puerto {PORT}")
    yield

app = FastAPI(title="Chatbot WA SaaS by Simplex", lifespan=lifespan)

# ── Helpers Green API ──────────────────────────────────────────────────────────
def green_base(instance: str, server: str) -> str:
    return f"https://{server}.api.greenapi.com/waInstance{instance}"

async def send_whatsapp(instance: str, token: str, server: str, chat_id: str, message: str) -> bool:
    base = green_base(instance, server)
    try:
        async with httpx.AsyncClient(timeout=12) as client:
            r = await client.post(
                f"{base}/sendMessage/{token}",
                json={"chatId": chat_id, "message": message}
            )
            return r.status_code == 200
    except Exception as e:
        log.error(f"WA send error: {e}")
        return False

async def send_whatsapp_image(instance: str, token: str, server: str, chat_id: str, img_path: Path, caption: str = "") -> bool:
    base = green_base(instance, server)
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            with img_path.open("rb") as f:
                r = await client.post(
                    f"{base}/sendFileByUpload/{token}",
                    data={"chatId": chat_id, "caption": caption},
                    files={"file": (img_path.name, f, "image/jpeg")}
                )
            return r.status_code == 200
    except Exception as e:
        log.error(f"WA image send error: {e}")
        return False

KEYWORDS_PRODUCTOS = {
    "taza": ["taza", "mug", "vasito"],
    "termo": ["termo", "yeti", "botella"],
    "playera": ["playera", "polo", "camiseta", "shirt"],
    "boxer": ["boxer", "bóxer", "ropa interior"],
    "llavero": ["llavero", "llave"],
    "servilletero": ["servilletero", "servilleta"],
    "posavasos": ["posavasos", "coaster"],
    "caja": ["caja", "cajita", "estuche"],
    "tabla": ["tabla", "tablon", "madera"],
    "porta_menu": ["menú", "menu", "carta"],
    "sticker": ["sticker", "calcomanía", "etiqueta"],
    "senaletica": ["señalética", "señal", "letrero", "hotel"],
    "acrilico": ["acrílico", "acrilico"],
}

def buscar_imagenes_producto(cid: int, texto: str) -> list[Path]:
    folder = carpeta_de(cid)
    if not folder:
        return []
    prod_dir = folder / "productos"
    if not prod_dir.exists():
        return []
    texto_lower = texto.lower()
    keywords_encontradas = set()
    for categoria, palabras in KEYWORDS_PRODUCTOS.items():
        if any(p in texto_lower for p in palabras):
            keywords_encontradas.add(categoria)
    if not keywords_encontradas:
        return []
    imagenes = []
    for img in prod_dir.iterdir():
        if img.suffix.lower() not in (".jpg", ".jpeg", ".png", ".webp"):
            continue
        nombre_lower = img.stem.lower()
        if any(k in nombre_lower for k in keywords_encontradas):
            imagenes.append(img)
    return imagenes[:3]

async def get_wa_estado(instance: str, token: str, server: str) -> str:
    base = green_base(instance, server)
    try:
        async with httpx.AsyncClient(timeout=8) as client:
            r = await client.get(f"{base}/getStateInstance/{token}")
            return r.json().get("stateInstance", "unknown")
    except Exception:
        return "error"

async def get_qr_code(instance: str, token: str, server: str) -> Optional[str]:
    base = green_base(instance, server)
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            r = await client.get(f"{base}/qr/{token}")
            data = r.json()
            return data.get("base64Qr")
    except Exception:
        return None

# ── Groq AI ───────────────────────────────────────────────────────────────────
async def generar_respuesta(config: dict, historial: list, mensaje_usuario: str) -> str:
    productos = json.loads(config.get("productos", "[]"))
    faq       = json.loads(config.get("faq", "[]"))

    # Prioriza catalogo.txt si existe
    cat_txt = leer_catalogo_txt(config.get("cliente_id", 0), config.get("descripcion", ""))
    if cat_txt:
        productos_txt = cat_txt
    else:
        productos_txt = "\n".join([f"- {p['nombre']}: {p['precio']}" for p in productos]) if productos else "No especificados"
    faq_txt = "\n".join([f"P: {f['pregunta']}\nR: {f['respuesta']}" for f in faq]) if faq else ""

    # Sección de acciones disponibles (se activa según config del cliente)
    acciones_txt = ""
    if config.get("permite_pedidos", 1):
        acciones_txt += """
TOMAR PEDIDOS: Cuando el cliente quiera comprar, recolecta EN LA CONVERSACIÓN: su NOMBRE COMPLETO, qué PRODUCTO(S) y CANTIDAD quiere, FECHA de entrega deseada, y el MONTO aproximado según el catálogo. Cuando tengas los 4 datos completos (nombre, producto, cantidad, fecha), incluye AL FINAL de tu mensaje esta etiqueta exacta (sin espacios extras):
[[PEDIDO|nombre=NOMBRE|producto=PRODUCTO|cantidad=CANTIDAD|fecha=FECHA|monto=MONTO]]"""

    if config.get("permite_citas", 0):
        servicios_raw = config.get("servicios", "[]")
        servicios_list = json.loads(servicios_raw) if servicios_raw else []
        servicios_str = ", ".join(servicios_list) if servicios_list else "el servicio que ofrece el negocio"
        horarios_raw = config.get("horarios_cita", "[]")
        horarios_list = json.loads(horarios_raw) if horarios_raw else []
        horarios_str = ", ".join(horarios_list) if horarios_list else "en los horarios disponibles"
        acciones_txt += f"""
AGENDAR CITAS: Cuando el cliente quiera una cita, recolecta: NOMBRE COMPLETO, SERVICIO deseado ({servicios_str}), FECHA y HORA ({horarios_str}). Cuando tengas los 4 datos, incluye AL FINAL:
[[CITA|nombre=NOMBRE|servicio=SERVICIO|fecha=FECHA|hora=HORA]]"""

    acciones_txt += """
DATOS DE CONTACTO: Si alguien pregunta sin comprar todavía, puedes ofrecerte a guardar sus datos para darle seguimiento. Si acepta, incluye al final:
[[LEAD|nombre=NOMBRE|interes=QUE_PREGUNTO]]
TRANSFERIR A HUMANO: Si el cliente pide explícitamente hablar con una persona, incluye al final:
[[HUMANO]]"""

    system_prompt = f"""Eres {config['nombre_bot']}, asistente de WhatsApp de {config['descripcion'] or 'este negocio'}.

HORARIO: {config['horario']}
PRODUCTOS/SERVICIOS:
{productos_txt}

{f'PREGUNTAS FRECUENTES:{chr(10)}{faq_txt}' if faq_txt else ''}

{config.get('prompt_extra', '')}
{acciones_txt}

REGLAS:
- Responde en español, de forma amable y breve (máximo 3 párrafos)
- Si preguntan algo que no sabes, di que le avisarás al equipo y pedirás datos de contacto
- Si piden cotización, da el precio de la lista. Si no está, pide detalles y di que te comunicas en breve
- Nunca inventes precios ni información que no tengas
- Usa emojis con moderación, máximo 2 por mensaje
- Si el cliente quiere hablar con una persona, di que en {config['horario']} pueden llamar
- Las etiquetas [[...]] NO son visibles para el cliente — solo son señales internas"""

    messages = [{"role": "system", "content": system_prompt}]
    for h in historial[-6:]:
        messages.append({"role": h["rol"], "content": h["texto"]})
    messages.append({"role": "user", "content": mensaje_usuario})

    try:
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.post(
                "https://api.groq.com/openai/v1/chat/completions",
                headers={"Authorization": f"Bearer {GROQ_KEY}", "Content-Type": "application/json"},
                json={"model": GROQ_MODEL, "messages": messages, "max_tokens": 400, "temperature": 0.7}
            )
            data = r.json()
            return data["choices"][0]["message"]["content"].strip()
    except Exception as e:
        log.error(f"Groq error: {e}")
        return "En este momento tenemos un inconveniente técnico. Por favor intenta en unos minutos."

# ── Webhook por cliente ────────────────────────────────────────────────────────
@app.post("/webhook/{cliente_id}")
async def webhook_mensaje(cliente_id: int, request: Request):
    try:
        body = await request.json()
    except Exception:
        return {"ok": False}

    tipo = body.get("typeWebhook", "")
    if tipo != "incomingMessageReceived":
        return {"ok": True, "msg": "ignorado"}

    msg_data = body.get("messageData", {})
    if msg_data.get("typeMessage") not in ("textMessage", "extendedTextMessage"):
        return {"ok": True, "msg": "no texto"}

    chat_id = body.get("senderData", {}).get("chatId", "")
    texto   = msg_data.get("textMessageData", {}).get("textMessage") or \
              msg_data.get("extendedTextMessageData", {}).get("text", "")

    if not chat_id or not texto:
        return {"ok": False}

    db = get_db()
    try:
        cliente = db.execute("SELECT * FROM clientes WHERE id=? AND activo=1", (cliente_id,)).fetchone()
        if not cliente:
            return {"ok": False, "msg": "cliente no encontrado"}

        # ── Verificar licencia prepago ─────────────────────────────────────────
        from datetime import date as _date
        vencimiento = cliente["fecha_vencimiento"] if "fecha_vencimiento" in cliente.keys() else None
        if vencimiento and vencimiento < str(_date.today()):
            await send_whatsapp(
                cliente["green_instance"], cliente["green_token"],
                cliente["green_server"], chat_id,
                "🔒 El servicio de asistente automático está suspendido. Contacta directamente al negocio."
            )
            log.warning(f"Cliente {cliente_id} [{cliente['nombre_negocio']}] — licencia VENCIDA desde {vencimiento}")
            return {"ok": False, "msg": "licencia vencida"}

        config = db.execute("SELECT * FROM config_bot WHERE cliente_id=?", (cliente_id,)).fetchone()
        if not config:
            return {"ok": False, "msg": "sin config"}

        # Registrar mensaje entrante
        db.execute("INSERT INTO mensajes (cliente_id, chat_id, direccion, texto) VALUES (?,?,?,?)",
                   (cliente_id, chat_id, "in", texto))
        db.commit()

        # Cargar/actualizar historial
        conv = db.execute("SELECT * FROM conversaciones WHERE cliente_id=? AND chat_id=?",
                          (cliente_id, chat_id)).fetchone()
        historial = json.loads(conv["historial"]) if conv else []
        historial.append({"rol": "user", "texto": texto})

        # Generar respuesta con IA
        config_dict = dict(config)
        config_dict["cliente_id"] = cliente_id
        respuesta_raw = await generar_respuesta(config_dict, historial, texto)

        # Extraer y ejecutar acciones, limpiar texto visible
        respuesta_visible, acciones = extraer_acciones(respuesta_raw)
        historial.append({"rol": "assistant", "texto": respuesta_visible})

        # Guardar historial (máximo 20 turnos)
        if len(historial) > 20:
            historial = historial[-20:]

        if conv:
            db.execute("UPDATE conversaciones SET historial=?, ultima_actividad=datetime('now') WHERE cliente_id=? AND chat_id=?",
                       (json.dumps(historial), cliente_id, chat_id))
        else:
            db.execute("INSERT INTO conversaciones (cliente_id, chat_id, historial) VALUES (?,?,?)",
                       (cliente_id, chat_id, json.dumps(historial)))
        db.commit()

        # Registrar respuesta saliente
        db.execute("INSERT INTO mensajes (cliente_id, chat_id, direccion, texto) VALUES (?,?,?,?)",
                   (cliente_id, chat_id, "out", respuesta_visible))
        db.commit()

        # Enviar texto al cliente
        await send_whatsapp(
            cliente["green_instance"], cliente["green_token"],
            cliente["green_server"], chat_id, respuesta_visible
        )

        # Ejecutar acciones detectadas
        for accion in acciones:
            msgs_extra = await ejecutar_accion(accion, dict(cliente), config_dict, chat_id, db)
            for msg in msgs_extra:
                await send_whatsapp(
                    cliente["green_instance"], cliente["green_token"],
                    cliente["green_server"], chat_id, msg
                )

        # Enviar imágenes si el mensaje pregunta por un producto
        imagenes = buscar_imagenes_producto(cliente_id, texto)
        for img in imagenes:
            await send_whatsapp_image(
                cliente["green_instance"], cliente["green_token"],
                cliente["green_server"], chat_id, img, ""
            )

        return {"ok": True}

    finally:
        db.close()

# ── Admin API ──────────────────────────────────────────────────────────────────
def check_admin(key: str = ""):
    if key != ADMIN_KEY:
        raise HTTPException(401, "No autorizado")

@app.get("/admin")
async def admin_panel():
    return FileResponse(TEMPLATES / "admin.html", media_type="text/html")

@app.get("/api/clientes")
async def listar_clientes(key: str = ""):
    check_admin(key)
    db = get_db()
    rows = db.execute("""
        SELECT c.*, cfg.nombre_bot, cfg.descripcion,
               (SELECT COUNT(*) FROM mensajes m WHERE m.cliente_id=c.id AND date(m.timestamp)=date('now')) as msgs_hoy
        FROM clientes c
        LEFT JOIN config_bot cfg ON cfg.cliente_id=c.id
        ORDER BY c.id DESC
    """).fetchall()
    db.close()
    return [dict(r) for r in rows]

class ClienteIn(BaseModel):
    nombre_negocio: str
    nombre_contacto: Optional[str] = ""
    telefono: Optional[str] = ""
    email: Optional[str] = ""
    green_instance: str
    green_token: str
    green_server: str = "7107"
    plan: str = "basico"
    precio_mensual: int = 900
    nombre_bot: str = "Asistente"
    saludo: str = "¡Hola! ¿En qué te puedo ayudar? 😊"
    descripcion: str = ""
    horario: str = "Lun-Sáb 9am-7pm"
    productos: str = "[]"
    faq: str = "[]"
    prompt_extra: str = ""
    notas: Optional[str] = ""

@app.post("/api/clientes")
async def crear_cliente(data: ClienteIn, key: str = ""):
    check_admin(key)
    db = get_db()
    try:
        cur = db.execute("""
            INSERT INTO clientes (nombre_negocio, nombre_contacto, telefono, email,
                green_instance, green_token, green_server, plan, precio_mensual, notas)
            VALUES (?,?,?,?,?,?,?,?,?,?)
        """, (data.nombre_negocio, data.nombre_contacto, data.telefono, data.email,
              data.green_instance, data.green_token, data.green_server,
              data.plan, data.precio_mensual, data.notas))
        cid = cur.lastrowid
        carpeta_cliente(cid, data.nombre_negocio)
        db.execute("""
            INSERT INTO config_bot (cliente_id, nombre_bot, saludo, descripcion,
                productos, faq, horario, prompt_extra)
            VALUES (?,?,?,?,?,?,?,?)
        """, (cid, data.nombre_bot, data.saludo, data.descripcion,
              data.productos, data.faq, data.horario, data.prompt_extra))
        db.commit()

        dominio = DOMINIO_PUBLICO
        webhook_url = f"{dominio}/webhook/{cid}"
        link_cat = f"{dominio}/catalogo/{cid}/{token_cliente(cid, data.green_instance)}"
        return {
            "ok": True,
            "cliente_id": cid,
            "webhook_url": webhook_url,
            "link_catalogo": link_cat,
            "instruccion": f"1) Configura webhook en Green API: {webhook_url}  2) Enlace catálogo para el cliente: {link_cat}"
        }
    finally:
        db.close()

@app.get("/api/clientes/{cid}")
async def get_cliente(cid: int, key: str = ""):
    check_admin(key)
    db = get_db()
    c = db.execute("SELECT * FROM clientes WHERE id=?", (cid,)).fetchone()
    cfg = db.execute("SELECT * FROM config_bot WHERE cliente_id=?", (cid,)).fetchone()
    db.close()
    if not c:
        raise HTTPException(404)
    return {"cliente": dict(c), "config": dict(cfg) if cfg else {}}

@app.put("/api/clientes/{cid}")
async def actualizar_cliente(cid: int, data: ClienteIn, key: str = ""):
    check_admin(key)
    db = get_db()
    db.execute("""
        UPDATE clientes SET nombre_negocio=?, nombre_contacto=?, telefono=?,
            email=?, plan=?, precio_mensual=?, activo=1, notas=?
        WHERE id=?
    """, (data.nombre_negocio, data.nombre_contacto, data.telefono,
          data.email, data.plan, data.precio_mensual, data.notas, cid))
    db.execute("""
        UPDATE config_bot SET nombre_bot=?, saludo=?, descripcion=?,
            productos=?, faq=?, horario=?, prompt_extra=?
        WHERE cliente_id=?
    """, (data.nombre_bot, data.saludo, data.descripcion,
          data.productos, data.faq, data.horario, data.prompt_extra, cid))
    db.commit()
    db.close()
    return {"ok": True}

@app.delete("/api/clientes/{cid}")
async def desactivar_cliente(cid: int, key: str = ""):
    check_admin(key)
    db = get_db()
    db.execute("UPDATE clientes SET activo=0 WHERE id=?", (cid,))
    db.commit()
    db.close()
    return {"ok": True}

@app.post("/api/clientes/{cid}/renovar")
async def renovar_licencia(cid: int, meses: int = 1, key: str = ""):
    check_admin(key)
    db = get_db()
    c = db.execute("SELECT fecha_vencimiento FROM clientes WHERE id=?", (cid,)).fetchone()
    if not c:
        raise HTTPException(404)
    from datetime import date, timedelta
    base = c["fecha_vencimiento"] or str(date.today())
    # Si ya venció, renovar desde hoy; si aún vigente, sumar al vencimiento actual
    base_date = max(date.fromisoformat(base), date.today())
    nueva = base_date + timedelta(days=30 * meses)
    db.execute("UPDATE clientes SET fecha_vencimiento=?, activo=1, es_demo=0 WHERE id=?",
               (str(nueva), cid))
    db.commit()
    db.close()
    return {"ok": True, "vencimiento_nuevo": str(nueva), "meses": meses}

@app.post("/api/clientes/{cid}/suspender")
async def suspender_cliente(cid: int, key: str = ""):
    check_admin(key)
    from datetime import date, timedelta
    ayer = str(date.today() - timedelta(days=1))
    db = get_db()
    db.execute("UPDATE clientes SET fecha_vencimiento=? WHERE id=?", (ayer, cid))
    db.commit()
    db.close()
    return {"ok": True, "msg": "Cliente suspendido — bot bloqueado inmediatamente"}

@app.get("/api/licencias")
async def estado_licencias(key: str = ""):
    check_admin(key)
    from datetime import date
    hoy = str(date.today())
    db = get_db()
    rows = db.execute("""
        SELECT id, nombre_negocio, plan, fecha_vencimiento, es_demo, activo,
               CASE WHEN fecha_vencimiento < ? THEN 'VENCIDO'
                    WHEN fecha_vencimiento <= date(?, '+5 days') THEN 'POR VENCER'
                    ELSE 'VIGENTE' END as estado_licencia
        FROM clientes ORDER BY fecha_vencimiento ASC
    """, (hoy, hoy)).fetchall()
    db.close()
    return [dict(r) for r in rows]

@app.get("/api/clientes/{cid}/estado")
async def estado_cliente(cid: int, key: str = ""):
    check_admin(key)
    db = get_db()
    c = db.execute("SELECT * FROM clientes WHERE id=?", (cid,)).fetchone()
    db.close()
    if not c:
        raise HTTPException(404)
    estado = await get_wa_estado(c["green_instance"], c["green_token"], c["green_server"])
    return {"cliente_id": cid, "nombre": c["nombre_negocio"], "estado_wa": estado}

@app.get("/api/clientes/{cid}/mensajes")
async def mensajes_cliente(cid: int, limite: int = 50, key: str = ""):
    check_admin(key)
    db = get_db()
    rows = db.execute(
        "SELECT * FROM mensajes WHERE cliente_id=? ORDER BY id DESC LIMIT ?",
        (cid, limite)
    ).fetchall()
    db.close()
    return [dict(r) for r in rows]

@app.get("/api/stats")
async def stats_globales(key: str = ""):
    check_admin(key)
    db = get_db()
    total  = db.execute("SELECT COUNT(*) FROM clientes WHERE activo=1").fetchone()[0]
    hoy    = db.execute("SELECT COUNT(*) FROM mensajes WHERE date(timestamp)=date('now')").fetchone()[0]
    mes    = db.execute("SELECT COUNT(*) FROM mensajes WHERE strftime('%Y-%m', timestamp)=strftime('%Y-%m', 'now')").fetchone()[0]
    ingreso = db.execute("SELECT COALESCE(SUM(precio_mensual),0) FROM clientes WHERE activo=1").fetchone()[0]
    db.close()
    return {
        "clientes_activos": total,
        "mensajes_hoy": hoy,
        "mensajes_mes": mes,
        "ingreso_mensual_estimado": ingreso
    }

@app.get("/api/clientes/{cid}/qr")
async def qr_cliente(cid: int, key: str = ""):
    check_admin(key)
    db = get_db()
    c = db.execute("SELECT * FROM clientes WHERE id=?", (cid,)).fetchone()
    db.close()
    if not c:
        raise HTTPException(404)
    qr = await get_qr_code(c["green_instance"], c["green_token"], c["green_server"])
    if not qr:
        return {"ok": False, "msg": "QR no disponible — posiblemente ya conectado"}
    return {"ok": True, "qr_base64": qr}

@app.post("/api/clientes/{cid}/sincronizar-catalogo")
async def sincronizar_catalogo(cid: int, key: str = ""):
    check_admin(key)
    db = get_db()
    c = db.execute("SELECT * FROM clientes WHERE id=?", (cid,)).fetchone()
    db.close()
    if not c:
        raise HTTPException(404)
    return await sincronizar_catalogo_wa(cid, c["green_instance"], c["green_token"], c["green_server"])

# ── Portal del cliente (sin admin key — acceso por token propio) ───────────────
import hashlib, secrets

def token_cliente(cid: int, instance: str) -> str:
    return hashlib.sha256(f"{cid}:{instance}:simplex".encode()).hexdigest()[:16]

@app.get("/catalogo/{cid}/{ctok}")
async def portal_catalogo(cid: int, ctok: str):
    db = get_db()
    c = db.execute("SELECT * FROM clientes WHERE id=? AND activo=1", (cid,)).fetchone()
    db.close()
    if not c or token_cliente(cid, c["green_instance"]) != ctok:
        raise HTTPException(403, "Enlace inválido")
    tpl = (TEMPLATES / "catalogo_cliente.html").read_text(encoding="utf-8")
    tpl = tpl.replace("{{CID}}", str(cid)).replace("{{CTOK}}", ctok).replace("{{NEGOCIO}}", c["nombre_negocio"])
    return HTMLResponse(tpl)

@app.get("/catalogo-txt/{cid}/{ctok}")
async def portal_catalogo_txt(cid: int, ctok: str):
    """Devuelve el contenido crudo de catalogo.txt para el portal del cliente."""
    db = get_db()
    c = db.execute("SELECT * FROM clientes WHERE id=? AND activo=1", (cid,)).fetchone()
    db.close()
    if not c or token_cliente(cid, c["green_instance"]) != ctok:
        raise HTTPException(403, "Token inválido")
    folder = carpeta_de(cid)
    if not folder:
        return PlainTextResponse("")
    cat = folder / "catalogo.txt"
    return PlainTextResponse(cat.read_text(encoding="utf-8") if cat.exists() else "")

@app.get("/api/clientes/{cid}/link-catalogo")
async def link_catalogo(cid: int, key: str = ""):
    check_admin(key)
    db = get_db()
    c = db.execute("SELECT * FROM clientes WHERE id=?", (cid,)).fetchone()
    db.close()
    if not c:
        raise HTTPException(404)
    tok = token_cliente(cid, c["green_instance"])
    dominio = os.getenv("DOMINIO_PUBLICO", "https://enrique-slaty-afton.ngrok-free.dev")
    return {"link": f"{dominio}/catalogo/{cid}/{tok}", "nota": "Envía este link al cliente para que edite su catálogo"}

# Guardar catálogo desde portal del cliente (usa token de cliente, sin admin key)
@app.put("/catalogo/{cid}/{ctok}")
async def portal_guardar_catalogo(cid: int, ctok: str, request: Request):
    db = get_db()
    c = db.execute("SELECT * FROM clientes WHERE id=? AND activo=1", (cid,)).fetchone()
    db.close()
    if not c or token_cliente(cid, c["green_instance"]) != ctok:
        raise HTTPException(403, "Token inválido")
    body = await request.json()
    contenido = body.get("contenido", "")
    matches = [d for d in CLIENTES_DIR.iterdir() if d.name.startswith(f"{cid:04d}_")]
    folder = matches[0] if matches else carpeta_cliente(cid, c["nombre_negocio"])
    (folder / "catalogo.txt").write_text(contenido, encoding="utf-8")
    return {"ok": True}

# ── Fotos desde portal del cliente (token propio, sin admin key) ──────────────
from fastapi import UploadFile, File as FastFile, Form as FastForm
import shutil

CATEGORIAS_FOTOS = {
    "taza": "Taza / Mug", "termo": "Termo", "playera": "Playera",
    "boxer": "Boxer / Ropa", "llavero": "Llavero", "servilletero": "Servilletero",
    "posavasos": "Posavasos", "caja": "Caja MDF", "tabla": "Tabla de servicio",
    "sticker": "Sticker", "senaletica": "Señalética", "acrilico": "Acrílico",
    "copa": "Copa / Cristal", "caballito": "Caballito", "tarro": "Tarro cervecero",
    "lamina": "Lámina sublimada", "mouse_pad": "Mouse pad", "azulejo": "Azulejo",
    "rompecabezas": "Rompecabezas", "panialero": "Pañalero",
}

def _validar_token_cliente(cid: int, ctok: str):
    db = get_db()
    c = db.execute("SELECT * FROM clientes WHERE id=? AND activo=1", (cid,)).fetchone()
    db.close()
    if not c or token_cliente(cid, c["green_instance"]) != ctok:
        raise HTTPException(403, "Token inválido")
    return c

@app.get("/api/catalogo/{cid}/{ctok}/fotos")
async def listar_fotos_cliente(cid: int, ctok: str):
    c = _validar_token_cliente(cid, ctok)
    folder = carpeta_de(cid) or carpeta_cliente(cid, c["nombre_negocio"])
    prod_dir = folder / "productos"
    fotos = []
    if prod_dir.exists():
        for f in sorted(prod_dir.iterdir()):
            if f.suffix.lower() in (".jpg", ".jpeg", ".png", ".webp"):
                stem = f.stem.lower()
                cat_key = next((k for k in CATEGORIAS_FOTOS if stem.startswith(k)), "otro")
                cat_label = CATEGORIAS_FOTOS.get(cat_key, stem)
                fotos.append({"nombre": f.name, "categoria": cat_label, "url": f"/foto/{cid}/{ctok}/{f.name}"})
    return {"ok": True, "fotos": fotos}

@app.get("/foto/{cid}/{ctok}/{nombre}")
async def ver_foto_cliente(cid: int, ctok: str, nombre: str):
    _validar_token_cliente(cid, ctok)
    folder = carpeta_de(cid)
    if not folder:
        raise HTTPException(404)
    archivo = folder / "productos" / nombre
    if not archivo.exists():
        raise HTTPException(404)
    return FileResponse(str(archivo))

@app.post("/api/catalogo/{cid}/{ctok}/fotos")
async def subir_foto_cliente(cid: int, ctok: str,
                              categoria: str = FastForm(...),
                              file: UploadFile = FastFile(...)):
    c = _validar_token_cliente(cid, ctok)
    if categoria not in CATEGORIAS_FOTOS:
        raise HTTPException(400, "Categoría inválida")
    ext = Path(file.filename).suffix.lower() if file.filename else ".jpg"
    if ext not in (".jpg", ".jpeg", ".png", ".webp"):
        raise HTTPException(400, "Solo se permiten imágenes JPG, PNG o WEBP")
    folder = carpeta_de(cid) or carpeta_cliente(cid, c["nombre_negocio"])
    prod_dir = folder / "productos"
    prod_dir.mkdir(exist_ok=True)
    # Auto-numerar: taza_01.jpg, taza_02.jpg...
    existentes = [f for f in prod_dir.iterdir() if f.stem.lower().startswith(categoria)]
    num = len(existentes) + 1
    nombre_final = f"{categoria}_{num:02d}{ext}"
    dest = prod_dir / nombre_final
    with dest.open("wb") as f_out:
        shutil.copyfileobj(file.file, f_out)
    return {"ok": True, "nombre": nombre_final, "url": f"/foto/{cid}/{ctok}/{nombre_final}"}

@app.delete("/api/catalogo/{cid}/{ctok}/fotos/{nombre}")
async def eliminar_foto_cliente(cid: int, ctok: str, nombre: str):
    _validar_token_cliente(cid, ctok)
    folder = carpeta_de(cid)
    if not folder:
        raise HTTPException(404)
    archivo = folder / "productos" / nombre
    if archivo.exists():
        archivo.unlink()
    return {"ok": True}

@app.post("/api/catalogo/{cid}/{ctok}/sync-fotos-fb")
async def sync_fotos_fb_cliente(cid: int, ctok: str):
    """Sync fotos desde Facebook Page — autenticado con token de cliente."""
    c = _validar_token_cliente(cid, ctok)
    page_id    = c["fb_page_id"]
    page_token = c["fb_page_token"]
    if not page_id or not page_token:
        return {"ok": False, "msg": "Token de Facebook no configurado. Contacta a Simplex para activarlo."}
    folder   = carpeta_de(cid) or carpeta_cliente(cid, c["nombre_negocio"])
    prod_dir = folder / "productos"
    prod_dir.mkdir(exist_ok=True)
    descargadas, omitidas, errores, after = 0, 0, 0, None
    while True:
        params = {"fields": "message,full_picture", "limit": "50", "access_token": page_token}
        if after:
            params["after"] = after
        try:
            async with httpx.AsyncClient(timeout=20) as client:
                r = await client.get(f"https://graph.facebook.com/v18.0/{page_id}/posts", params=params)
            data = r.json()
        except Exception as e:
            return {"ok": False, "msg": str(e)}
        if "error" in data:
            return {"ok": False, "msg": data["error"].get("message", str(data["error"]))}
        for post in data.get("data", []):
            img_url = post.get("full_picture", "")
            caption = post.get("message", "")
            if not img_url:
                continue
            cat = detectar_categoria_foto(caption)
            if not cat:
                omitidas += 1
                continue
            existentes = [f for f in prod_dir.iterdir() if f.stem.lower().startswith(cat)]
            num  = len(existentes) + 1
            dest = prod_dir / f"{cat}_{num:02d}.jpg"
            if not dest.exists():
                ok = await _descargar_foto(img_url, dest)
                descargadas += 1 if ok else 0
                errores     += 0 if ok else 1
            else:
                omitidas += 1
        cursor = data.get("paging", {}).get("cursors", {}).get("after")
        if not cursor or not data.get("paging", {}).get("next"):
            break
        after = cursor
    return {"ok": True, "descargadas": descargadas, "omitidas": omitidas, "errores": errores}

@app.post("/api/catalogo/{cid}/{ctok}/sync-fotos-ig")
async def sync_fotos_ig_cliente(cid: int, ctok: str):
    """Sync fotos desde Instagram — autenticado con token de cliente."""
    c = _validar_token_cliente(cid, ctok)
    ig_token = c["ig_token"]
    if not ig_token:
        return {"ok": False, "msg": "Token de Instagram no configurado. Contacta a Simplex para activarlo."}
    folder   = carpeta_de(cid) or carpeta_cliente(cid, c["nombre_negocio"])
    prod_dir = folder / "productos"
    prod_dir.mkdir(exist_ok=True)
    descargadas, omitidas, errores, after = 0, 0, 0, None
    while True:
        params = {"fields": "caption,media_type,media_url,thumbnail_url", "limit": "50", "access_token": ig_token}
        if after:
            params["after"] = after
        try:
            async with httpx.AsyncClient(timeout=20) as client:
                r = await client.get("https://graph.facebook.com/v18.0/me/media", params=params)
            data = r.json()
        except Exception as e:
            return {"ok": False, "msg": str(e)}
        if "error" in data:
            return {"ok": False, "msg": data["error"].get("message", str(data["error"]))}
        for media in data.get("data", []):
            mtype   = media.get("media_type", "")
            caption = media.get("caption", "")
            img_url = media.get("media_url") or media.get("thumbnail_url", "")
            if mtype == "VIDEO":
                img_url = media.get("thumbnail_url", "")
            if not img_url:
                continue
            cat = detectar_categoria_foto(caption)
            if not cat:
                omitidas += 1
                continue
            existentes = [f for f in prod_dir.iterdir() if f.stem.lower().startswith(cat)]
            num  = len(existentes) + 1
            dest = prod_dir / f"{cat}_{num:02d}.jpg"
            if not dest.exists():
                ok = await _descargar_foto(img_url, dest)
                descargadas += 1 if ok else 0
                errores     += 0 if ok else 1
            else:
                omitidas += 1
        cursor = data.get("paging", {}).get("cursors", {}).get("after")
        if not cursor or not data.get("paging", {}).get("next"):
            break
        after = cursor
    return {"ok": True, "descargadas": descargadas, "omitidas": omitidas, "errores": errores}

# ── Archivos por cliente (admin) ──────────────────────────────────────────────

@app.get("/api/clientes/{cid}/archivos")
async def listar_archivos(cid: int, key: str = ""):
    check_admin(key)
    db = get_db()
    c = db.execute("SELECT nombre_negocio FROM clientes WHERE id=?", (cid,)).fetchone()
    db.close()
    if not c:
        raise HTTPException(404)
    matches = [d for d in CLIENTES_DIR.iterdir() if d.name.startswith(f"{cid:04d}_")]
    if not matches:
        carpeta_cliente(cid, c["nombre_negocio"])
        matches = [d for d in CLIENTES_DIR.iterdir() if d.name.startswith(f"{cid:04d}_")]
    folder = matches[0]
    result = {}
    for sub in ("productos", "logo", "archivos"):
        subdir = folder / sub
        result[sub] = [f.name for f in subdir.iterdir() if f.is_file()] if subdir.exists() else []
    cat = folder / "catalogo.txt"
    result["catalogo"] = cat.read_text(encoding="utf-8") if cat.exists() else ""
    result["carpeta"] = str(folder)
    return result

@app.post("/api/clientes/{cid}/archivos/{subcarpeta}")
async def subir_archivo(cid: int, subcarpeta: str, file: UploadFile = FastFile(...), key: str = ""):
    check_admin(key)
    if subcarpeta not in ("productos", "logo", "archivos"):
        raise HTTPException(400, "Subcarpeta inválida")
    db = get_db()
    c = db.execute("SELECT nombre_negocio FROM clientes WHERE id=?", (cid,)).fetchone()
    db.close()
    if not c:
        raise HTTPException(404)
    matches = [d for d in CLIENTES_DIR.iterdir() if d.name.startswith(f"{cid:04d}_")]
    folder = matches[0] if matches else carpeta_cliente(cid, c["nombre_negocio"])
    dest = folder / subcarpeta / file.filename
    with dest.open("wb") as f:
        shutil.copyfileobj(file.file, f)
    return {"ok": True, "archivo": file.filename, "ruta": str(dest)}

@app.put("/api/clientes/{cid}/catalogo")
async def actualizar_catalogo(cid: int, request: Request, key: str = ""):
    check_admin(key)
    body = await request.json()
    contenido = body.get("contenido", "")
    db = get_db()
    c = db.execute("SELECT nombre_negocio FROM clientes WHERE id=?", (cid,)).fetchone()
    db.close()
    if not c:
        raise HTTPException(404)
    matches = [d for d in CLIENTES_DIR.iterdir() if d.name.startswith(f"{cid:04d}_")]
    folder = matches[0] if matches else carpeta_cliente(cid, c["nombre_negocio"])
    (folder / "catalogo.txt").write_text(contenido, encoding="utf-8")
    return {"ok": True}

@app.get("/api/clientes/{cid}/archivo/{subcarpeta}/{nombre}")
async def descargar_archivo(cid: int, subcarpeta: str, nombre: str, key: str = ""):
    check_admin(key)
    matches = [d for d in CLIENTES_DIR.iterdir() if d.name.startswith(f"{cid:04d}_")]
    if not matches:
        raise HTTPException(404)
    archivo = matches[0] / subcarpeta / nombre
    if not archivo.exists():
        raise HTTPException(404)
    return FileResponse(str(archivo))

# ── Página de ventas (pública) ─────────────────────────────────────────────────
@app.get("/")
async def landing():
    return FileResponse(TEMPLATES / "landing.html", media_type="text/html")

# ── Motor de acciones (pedidos, citas, pagos, leads) ─────────────────────────
import re as _re

def extraer_acciones(texto: str) -> tuple[str, list[dict]]:
    """Extrae etiquetas [[TIPO|k=v|...]] del texto, devuelve (texto_limpio, lista_de_acciones)."""
    patron = r'\[\[([A-Z]+)(?:\|([^\]]*))?\]\]'
    acciones = []
    for m in _re.finditer(patron, texto):
        tipo = m.group(1)
        params_raw = m.group(2) or ""
        params = {}
        for par in params_raw.split("|"):
            if "=" in par:
                k, v = par.split("=", 1)
                params[k.strip()] = v.strip()
        acciones.append({"tipo": tipo, "params": params})
    texto_limpio = _re.sub(patron, "", texto).strip()
    # Quitar líneas en blanco duplicadas
    texto_limpio = _re.sub(r'\n{3,}', '\n\n', texto_limpio).strip()
    return texto_limpio, acciones

async def ejecutar_accion(accion: dict, cliente: dict, config: dict, chat_id: str, db) -> list[str]:
    """Ejecuta una acción y devuelve mensajes extra para enviar al cliente."""
    tipo   = accion["tipo"]
    params = accion["params"]
    msgs   = []
    cid    = cliente["id"]

    if tipo == "PEDIDO":
        nombre   = params.get("nombre", "Cliente")
        producto = params.get("producto", "No especificado")
        cantidad = params.get("cantidad", "1")
        fecha    = params.get("fecha", "A confirmar")
        monto    = float(params.get("monto", 0) or 0)

        cur = db.execute("""
            INSERT INTO pedidos (cliente_id, chat_id, nombre_cliente, producto, cantidad, fecha_entrega, monto)
            VALUES (?,?,?,?,?,?,?)
        """, (cid, chat_id, nombre, producto, cantidad, fecha, monto))
        pedido_id = cur.lastrowid
        db.commit()

        # Generar link de pago si hay monto y MP configurado
        link_pago = ""
        if monto > 0 and MP_ACCESS_TOKEN:
            mp = await crear_checkout_mp(
                pedido_id,
                f"Pedido #{pedido_id} — {producto[:40]}",
                int(monto), "", f"pedido_{pedido_id}"
            )
            if mp.get("ok"):
                db.execute("UPDATE pedidos SET mp_link=? WHERE id=?", (mp["checkout_url"], pedido_id))
                db.commit()
                link_pago = mp["checkout_url"]

        # Notificar al dueño
        tel_notif = config.get("telefono_notificaciones", "")
        if tel_notif:
            t = tel_notif.replace("+","").replace("-","").replace(" ","")
            if len(t) == 10: t = f"52{t}"
            await send_whatsapp(cliente["green_instance"], cliente["green_token"],
                                cliente["green_server"], f"{t}@c.us",
                                f"🛒 *PEDIDO NUEVO #{pedido_id}*\n"
                                f"Cliente: {nombre}\nProducto: {producto}\nCantidad: {cantidad}\n"
                                f"Entrega: {fecha}\nMonto: ${monto:.0f}\nWA: {chat_id}")

        # Confirmar al cliente
        confirm = (f"✅ *Pedido #{pedido_id} registrado*\n"
                   f"📦 {producto} × {cantidad}\n"
                   f"📅 Entrega: {fecha}\n"
                   f"💰 Monto: ${monto:.0f}")
        if link_pago:
            confirm += f"\n\n💳 Pagar ahora:\n{link_pago}"
        else:
            confirm += "\n\nEn breve te confirmamos y te enviamos los datos de pago."
        msgs.append(confirm)
        log.info(f"Pedido #{pedido_id} creado — cliente {cid}")

    elif tipo == "CITA":
        nombre   = params.get("nombre", "Cliente")
        servicio = params.get("servicio", "No especificado")
        fecha    = params.get("fecha", "A confirmar")
        hora     = params.get("hora", "A confirmar")

        cur = db.execute("""
            INSERT INTO citas (cliente_id, chat_id, nombre_cliente, servicio, fecha, hora)
            VALUES (?,?,?,?,?,?)
        """, (cid, chat_id, nombre, servicio, fecha, hora))
        cita_id = cur.lastrowid
        db.commit()

        # Notificar al dueño
        tel_notif = config.get("telefono_notificaciones", "")
        if tel_notif:
            t = tel_notif.replace("+","").replace("-","").replace(" ","")
            if len(t) == 10: t = f"52{t}"
            await send_whatsapp(cliente["green_instance"], cliente["green_token"],
                                cliente["green_server"], f"{t}@c.us",
                                f"📅 *CITA NUEVA #{cita_id}*\n"
                                f"Cliente: {nombre}\nServicio: {servicio}\nFecha: {fecha}\nHora: {hora}\nWA: {chat_id}")

        msgs.append(f"📅 *Cita #{cita_id} agendada*\n"
                    f"✂️ {servicio}\n📆 {fecha} a las {hora}\n\n"
                    f"Te enviaremos un recordatorio 1 hora antes. ¡Nos vemos!")
        log.info(f"Cita #{cita_id} creada — cliente {cid}")

    elif tipo == "LEAD":
        nombre  = params.get("nombre", "Desconocido")
        interes = params.get("interes", "")
        db.execute("INSERT INTO leads (cliente_id, chat_id, nombre_cliente, interes) VALUES (?,?,?,?)",
                   (cid, chat_id, nombre, interes))
        db.commit()
        log.info(f"Lead guardado — cliente {cid}: {nombre}")

    elif tipo == "HUMANO":
        tel_notif = config.get("telefono_notificaciones", "")
        if tel_notif:
            t = tel_notif.replace("+","").replace("-","").replace(" ","")
            if len(t) == 10: t = f"52{t}"
            await send_whatsapp(cliente["green_instance"], cliente["green_token"],
                                cliente["green_server"], f"{t}@c.us",
                                f"👤 *Un cliente pide hablar con una persona*\nWA: {chat_id}")
        msgs.append("Entendido. Le avisaré a alguien del equipo para que te contacte en breve. 🙌")

    return msgs

async def enviar_recordatorios():
    """Revisa citas próximas y envía recordatorio WA 1 hora antes."""
    try:
        from datetime import datetime as _dt
        db = get_db()
        ahora = _dt.now()
        # Buscar citas confirmadas sin recordatorio, en la próxima hora
        citas = db.execute("""
            SELECT ci.*, cl.green_instance, cl.green_token, cl.green_server,
                   cb.nombre_bot
            FROM citas ci
            JOIN clientes cl ON cl.id = ci.cliente_id
            LEFT JOIN config_bot cb ON cb.cliente_id = ci.cliente_id
            WHERE ci.recordatorio = 0 AND ci.estado IN ('pendiente','confirmada')
        """).fetchall()
        for c in citas:
            try:
                fecha_hora_str = f"{c['fecha']} {c['hora']}"
                dt_cita = _dt.strptime(fecha_hora_str, "%Y-%m-%d %H:%M")
                diff_min = (dt_cita - ahora).total_seconds() / 60
                if 50 <= diff_min <= 70:
                    msg = (f"⏰ Recordatorio: tienes una cita para *{c['servicio']}* "
                           f"hoy a las {c['hora']}. ¡Te esperamos!")
                    await send_whatsapp(c["green_instance"], c["green_token"],
                                        c["green_server"], c["chat_id"], msg)
                    db.execute("UPDATE citas SET recordatorio=1 WHERE id=?", (c["id"],))
                    db.commit()
            except Exception:
                pass
        db.close()
    except Exception as e:
        log.error(f"enviar_recordatorios: {e}")

async def tarea_recordatorios():
    """Loop de fondo — corre cada 30 minutos."""
    while True:
        await asyncio.sleep(1800)
        await enviar_recordatorios()

# ── Admin endpoints: Pedidos ──────────────────────────────────────────────────
@app.get("/api/pedidos")
async def listar_pedidos(key: str = "", cid: int = 0, estado: str = ""):
    check_admin(key)
    db = get_db()
    q = "SELECT p.*, c.nombre_negocio FROM pedidos p JOIN clientes c ON c.id=p.cliente_id"
    conds, args = [], []
    if cid:
        conds.append("p.cliente_id=?"); args.append(cid)
    if estado:
        conds.append("p.estado=?"); args.append(estado)
    if conds:
        q += " WHERE " + " AND ".join(conds)
    q += " ORDER BY p.id DESC LIMIT 200"
    rows = db.execute(q, args).fetchall()
    db.close()
    return [dict(r) for r in rows]

@app.put("/api/pedidos/{pid}/estado")
async def actualizar_pedido(pid: int, request: Request, key: str = ""):
    check_admin(key)
    body  = await request.json()
    nuevo = body.get("estado", "")
    valid = {"nuevo","confirmado","en_proceso","listo","entregado","cancelado"}
    if nuevo not in valid:
        raise HTTPException(400, f"estado inválido — usa: {valid}")
    db = get_db()
    db.execute("UPDATE pedidos SET estado=? WHERE id=?", (nuevo, pid))
    db.commit()

    # Si el pedido está listo, avisar al cliente
    if nuevo == "listo":
        p = db.execute("""
            SELECT p.*, c.green_instance, c.green_token, c.green_server
            FROM pedidos p JOIN clientes c ON c.id=p.cliente_id WHERE p.id=?
        """, (pid,)).fetchone()
        db.close()
        if p:
            await send_whatsapp(p["green_instance"], p["green_token"], p["green_server"],
                                p["chat_id"],
                                f"🎉 ¡Tu pedido #{pid} está listo para entrega!\n"
                                f"📦 {p['producto']}\n"
                                "Pasa a recogerlo o coordina tu envío. 😊")
    else:
        db.close()
    return {"ok": True, "estado": nuevo}

# ── Admin endpoints: Citas ────────────────────────────────────────────────────
@app.get("/api/citas")
async def listar_citas(key: str = "", cid: int = 0, estado: str = ""):
    check_admin(key)
    db = get_db()
    q = "SELECT ci.*, c.nombre_negocio FROM citas ci JOIN clientes c ON c.id=ci.cliente_id"
    conds, args = [], []
    if cid:
        conds.append("ci.cliente_id=?"); args.append(cid)
    if estado:
        conds.append("ci.estado=?"); args.append(estado)
    if conds:
        q += " WHERE " + " AND ".join(conds)
    q += " ORDER BY ci.fecha ASC, ci.hora ASC LIMIT 200"
    rows = db.execute(q, args).fetchall()
    db.close()
    return [dict(r) for r in rows]

@app.put("/api/citas/{cid_cita}/estado")
async def actualizar_cita(cid_cita: int, request: Request, key: str = ""):
    check_admin(key)
    body  = await request.json()
    nuevo = body.get("estado", "")
    valid = {"pendiente","confirmada","completada","cancelada"}
    if nuevo not in valid:
        raise HTTPException(400, f"estado inválido — usa: {valid}")
    db = get_db()
    db.execute("UPDATE citas SET estado=? WHERE id=?", (nuevo, cid_cita))
    db.commit()
    if nuevo == "confirmada":
        ci = db.execute("""
            SELECT ci.*, c.green_instance, c.green_token, c.green_server
            FROM citas ci JOIN clientes c ON c.id=ci.cliente_id WHERE ci.id=?
        """, (cid_cita,)).fetchone()
        db.close()
        if ci:
            await send_whatsapp(ci["green_instance"], ci["green_token"], ci["green_server"],
                                ci["chat_id"],
                                f"✅ Tu cita de *{ci['servicio']}* el {ci['fecha']} "
                                f"a las {ci['hora']} está *confirmada*. ¡Te esperamos! 🗓️")
    elif nuevo == "cancelada":
        ci = db.execute("""
            SELECT ci.*, c.green_instance, c.green_token, c.green_server
            FROM citas ci JOIN clientes c ON c.id=ci.cliente_id WHERE ci.id=?
        """, (cid_cita,)).fetchone()
        db.close()
        if ci:
            await send_whatsapp(ci["green_instance"], ci["green_token"], ci["green_server"],
                                ci["chat_id"],
                                f"Lo sentimos, tu cita del {ci['fecha']} ha sido cancelada. "
                                "Escríbenos para reagendar. 📅")
    else:
        db.close()
    return {"ok": True, "estado": nuevo}

@app.get("/api/leads")
async def listar_leads(key: str = "", cid: int = 0):
    check_admin(key)
    db = get_db()
    q = "SELECT l.*, c.nombre_negocio FROM leads l JOIN clientes c ON c.id=l.cliente_id"
    if cid:
        q += f" WHERE l.cliente_id={cid}"
    q += " ORDER BY l.id DESC LIMIT 200"
    rows = db.execute(q).fetchall()
    db.close()
    return [dict(r) for r in rows]

@app.put("/api/clientes/{cid}/config-avanzado")
async def config_avanzado(cid: int, request: Request, key: str = ""):
    """Actualiza configuración avanzada: notificaciones, pedidos, citas, servicios, horarios."""
    check_admin(key)
    body = await request.json()
    db   = get_db()
    fields = ["telefono_notificaciones", "permite_pedidos", "permite_citas", "servicios", "horarios_cita"]
    sets   = [f"{f}=?" for f in fields if f in body]
    vals   = [body[f] for f in fields if f in body]
    if sets:
        db.execute(f"UPDATE config_bot SET {', '.join(sets)} WHERE cliente_id=?", vals + [cid])
        db.commit()
    db.close()
    return {"ok": True}

# ── Self-service signup + setup wizard ────────────────────────────────────────
import uuid as _uuid

class SignupIn(BaseModel):
    nombre_negocio:  str
    nombre_contacto: str
    telefono:        str
    email:           str = ""
    plan:            str = "basico"

async def crear_checkout_mp(signup_id: int, nombre: str, precio: int, email: str, setup_token: str) -> dict:
    if not MP_ACCESS_TOKEN:
        return {"ok": False, "msg": "MP_ACCESS_TOKEN no configurado — activa el pago manualmente desde /admin"}
    payload = {
        "items": [{"title": f"Bot WhatsApp — {nombre}", "quantity": 1,
                   "unit_price": float(precio), "currency_id": "MXN"}],
        "payer": {"email": email or "cliente@ejemplo.com"},
        "external_reference": f"signup_{signup_id}_{setup_token}",
        "notification_url": f"{DOMINIO_PUBLICO}/api/pagos/mp-webhook",
        "back_urls": {
            "success": f"{DOMINIO_PUBLICO}/setup/{setup_token}",
            "failure": f"{DOMINIO_PUBLICO}/signup?err=pago_fallido",
            "pending": f"{DOMINIO_PUBLICO}/setup/{setup_token}?pending=1"
        },
        "auto_return": "approved"
    }
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            r = await client.post(
                "https://api.mercadopago.com/checkout/preferences",
                headers={"Authorization": f"Bearer {MP_ACCESS_TOKEN}", "Content-Type": "application/json"},
                json=payload
            )
            if r.status_code not in (200, 201):
                return {"ok": False, "msg": f"MP error {r.status_code}"}
            data = r.json()
            return {"ok": True, "preference_id": data.get("id"),
                    "checkout_url": data.get("init_point"), "sandbox_url": data.get("sandbox_init_point")}
    except Exception as e:
        return {"ok": False, "msg": str(e)}

async def auto_configurar_webhook(instance: str, token: str, server: str, webhook_url: str) -> bool:
    base = green_base(instance, server)
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            r = await client.post(f"{base}/setSettings/{token}",
                                  json={"webhookUrl": webhook_url, "incomingWebhook": "yes"})
            return r.status_code == 200
    except Exception as e:
        log.error(f"auto_configurar_webhook: {e}")
        return False

@app.get("/signup")
async def signup_page():
    return FileResponse(TEMPLATES / "signup.html", media_type="text/html")

@app.get("/manual")
async def manual_page():
    return FileResponse(TEMPLATES / "manual_cliente.html", media_type="text/html")

@app.post("/api/signup")
async def crear_signup(data: SignupIn):
    db = get_db()
    setup_token = secrets.token_urlsafe(16)
    try:
        cur = db.execute("""
            INSERT INTO signups (nombre_negocio, nombre_contacto, telefono, email, plan, precio_mensual, setup_token)
            VALUES (?,?,?,?,?,?,?)
        """, (data.nombre_negocio, data.nombre_contacto, data.telefono, data.email, data.plan, 150, setup_token))
        signup_id = cur.lastrowid
        db.commit()

        mp = await crear_checkout_mp(signup_id, data.nombre_negocio, 150, data.email, setup_token)
        if mp.get("ok"):
            db.execute("UPDATE signups SET mp_preference_id=? WHERE id=?", (mp["preference_id"], signup_id))
            db.commit()

        return {
            "ok": True,
            "signup_id": signup_id,
            "setup_token": setup_token,
            "setup_url": f"{DOMINIO_PUBLICO}/setup/{setup_token}",
            "checkout_url": mp.get("checkout_url"),
            "mp_ok": mp.get("ok", False),
            "mp_msg": mp.get("msg", "")
        }
    finally:
        db.close()

@app.post("/api/pagos/mp-webhook")
async def mp_webhook(request: Request):
    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"ok": False}, status_code=200)

    if body.get("type") != "payment":
        return JSONResponse({"ok": True, "msg": "ignorado"}, status_code=200)

    payment_id = body.get("data", {}).get("id")
    if not payment_id or not MP_ACCESS_TOKEN:
        return JSONResponse({"ok": True}, status_code=200)

    try:
        async with httpx.AsyncClient(timeout=15) as client:
            r = await client.get(f"https://api.mercadopago.com/v1/payments/{payment_id}",
                                 headers={"Authorization": f"Bearer {MP_ACCESS_TOKEN}"})
            pago = r.json()

        if pago.get("status") != "approved":
            return JSONResponse({"ok": True, "msg": pago.get("status")}, status_code=200)

        ext_ref = pago.get("external_reference", "")
        if not ext_ref.startswith("signup_"):
            return JSONResponse({"ok": True, "msg": "ref no es signup"}, status_code=200)

        signup_id = int(ext_ref.split("_")[1])
        db = get_db()
        signup = db.execute("SELECT * FROM signups WHERE id=?", (signup_id,)).fetchone()
        if not signup:
            db.close()
            return JSONResponse({"ok": False}, status_code=200)

        db.execute("UPDATE signups SET estado='pagado', mp_payment_id=?, fecha_pago=datetime('now') WHERE id=?",
                   (str(payment_id), signup_id))
        db.commit()
        stoken = signup["setup_token"]
        tel    = signup["telefono"]
        nombre = signup["nombre_contacto"]
        db.close()

        if SENDER_INSTANCE and SENDER_TOKEN and tel:
            t = tel.replace("+", "").replace("-", "").replace(" ", "")
            if len(t) == 10:
                t = f"52{t}"
            chat_id = f"{t}@c.us"
            setup_url = f"{DOMINIO_PUBLICO}/setup/{stoken}"
            msg = (f"✅ ¡Pago recibido! Bienvenido/a {nombre}.\n\n"
                   f"Configura tu bot aquí (solo 5 min):\n{setup_url}")
            await send_whatsapp(SENDER_INSTANCE, SENDER_TOKEN, SENDER_SERVER, chat_id, msg)

        log.info(f"Pago confirmado: signup #{signup_id}")
        return JSONResponse({"ok": True}, status_code=200)
    except Exception as e:
        log.error(f"mp_webhook error: {e}")
        return JSONResponse({"ok": True}, status_code=200)

@app.get("/setup/{setup_token}")
async def setup_wizard(setup_token: str):
    db = get_db()
    s = db.execute("SELECT id FROM signups WHERE setup_token=?", (setup_token,)).fetchone()
    db.close()
    if not s:
        return HTMLResponse("<h1 style='font-family:sans-serif;padding:40px'>Enlace inválido o expirado.</h1>", status_code=404)
    return FileResponse(TEMPLATES / "setup.html", media_type="text/html")

@app.get("/api/setup/{setup_token}/info")
async def setup_info(setup_token: str):
    db = get_db()
    s = db.execute("SELECT nombre_negocio,nombre_contacto,plan,estado,cliente_id FROM signups WHERE setup_token=?",
                   (setup_token,)).fetchone()
    db.close()
    if not s:
        raise HTTPException(404, "Token inválido")
    return dict(s)

@app.post("/api/setup/{setup_token}/credenciales")
async def setup_credenciales(setup_token: str, request: Request):
    db = get_db()
    s = db.execute("SELECT * FROM signups WHERE setup_token=?", (setup_token,)).fetchone()
    if not s:
        db.close()
        raise HTTPException(404, "Token inválido")

    body     = await request.json()
    instance = body.get("green_instance", "").strip()
    token    = body.get("green_token", "").strip()
    server   = body.get("green_server", "7107").strip()
    nombre_bot = body.get("nombre_bot", s["nombre_negocio"]).strip() or s["nombre_negocio"]

    if not instance or not token:
        db.close()
        raise HTTPException(400, "Instance ID y token son requeridos")

    estado_wa = await get_wa_estado(instance, token, server)
    if estado_wa == "error":
        db.close()
        return {"ok": False, "msg": "No se pudo conectar. Verifica que el Instance ID y token sean correctos."}

    cid = s["cliente_id"]
    if not cid:
        cur = db.execute("""
            INSERT INTO clientes (nombre_negocio, nombre_contacto, telefono, email,
                green_instance, green_token, green_server, plan, precio_mensual, es_demo)
            VALUES (?,?,?,?,?,?,?,?,?,0)
        """, (s["nombre_negocio"], s["nombre_contacto"], s["telefono"], s["email"],
              instance, token, server, s["plan"], s["precio_mensual"]))
        cid = cur.lastrowid
        carpeta_cliente(cid, s["nombre_negocio"])
        db.execute("""
            INSERT INTO config_bot (cliente_id, nombre_bot, descripcion, horario)
            VALUES (?,?,?,?)
        """, (cid, nombre_bot, s["nombre_negocio"], "Lun-Sáb 9am-7pm"))
        db.execute("UPDATE signups SET cliente_id=? WHERE setup_token=?", (cid, setup_token))
    else:
        db.execute("UPDATE clientes SET green_instance=?, green_token=?, green_server=? WHERE id=?",
                   (instance, token, server, cid))

    from datetime import date, timedelta
    vence = str(date.today() + timedelta(days=30))
    db.execute("UPDATE clientes SET fecha_vencimiento=?, activo=1 WHERE id=?", (vence, cid))
    db.execute("UPDATE signups SET estado='activo' WHERE setup_token=?", (setup_token,))
    db.commit()
    db.close()

    webhook_url = f"{DOMINIO_PUBLICO}/webhook/{cid}"
    webhook_ok  = await auto_configurar_webhook(instance, token, server, webhook_url)

    link_cat = f"{DOMINIO_PUBLICO}/catalogo/{cid}/{token_cliente(cid, instance)}"
    return {
        "ok": True,
        "cliente_id": cid,
        "estado_wa": estado_wa,
        "webhook_configurado": webhook_ok,
        "vencimiento": vence,
        "link_catalogo": link_cat
    }

@app.get("/api/setup/{setup_token}/qr")
async def setup_qr(setup_token: str):
    db = get_db()
    s = db.execute("SELECT cliente_id FROM signups WHERE setup_token=?", (setup_token,)).fetchone()
    if not s or not s["cliente_id"]:
        db.close()
        return {"ok": False, "msg": "Primero guarda las credenciales"}
    c = db.execute("SELECT * FROM clientes WHERE id=?", (s["cliente_id"],)).fetchone()
    db.close()
    qr     = await get_qr_code(c["green_instance"], c["green_token"], c["green_server"])
    estado = await get_wa_estado(c["green_instance"], c["green_token"], c["green_server"])
    return {"ok": bool(qr), "qr_base64": qr, "estado_wa": estado}

@app.get("/api/setup/{setup_token}/estado")
async def setup_estado_wa(setup_token: str):
    db = get_db()
    s = db.execute("SELECT cliente_id FROM signups WHERE setup_token=?", (setup_token,)).fetchone()
    if not s or not s["cliente_id"]:
        db.close()
        return {"estado_wa": "notAuthorized", "conectado": False}
    c = db.execute("SELECT * FROM clientes WHERE id=?", (s["cliente_id"],)).fetchone()
    db.close()
    estado = await get_wa_estado(c["green_instance"], c["green_token"], c["green_server"])
    return {"estado_wa": estado, "conectado": estado == "authorized"}

@app.get("/api/signups")
async def listar_signups(key: str = ""):
    check_admin(key)
    db = get_db()
    rows = db.execute("SELECT * FROM signups ORDER BY id DESC").fetchall()
    db.close()
    return [dict(r) for r in rows]

@app.post("/api/signups/{sid}/activar-manual")
async def activar_manual(sid: int, key: str = ""):
    """Activa manualmente un signup sin cobro MP (para demos o pagos en efectivo)."""
    check_admin(key)
    db = get_db()
    s = db.execute("SELECT * FROM signups WHERE id=?", (sid,)).fetchone()
    if not s:
        db.close()
        raise HTTPException(404)
    db.execute("UPDATE signups SET estado='pagado', fecha_pago=datetime('now') WHERE id=?", (sid,))
    db.commit()
    db.close()
    return {"ok": True, "setup_url": f"{DOMINIO_PUBLICO}/setup/{s['setup_token']}",
            "msg": "Activo. Comparte el link de setup con el cliente."}

# ── Facebook Messenger + Instagram DMs ───────────────────────────────────────

CATEGORIA_KEYWORDS_FB = {
    "taza":         ["taza","mug","tasita","vaso cerámico"],
    "termo":        ["termo","yeti","botella","tumbler"],
    "playera":      ["playera","polo","camiseta","shirt"],
    "boxer":        ["boxer","bóxer","ropa interior"],
    "llavero":      ["llavero","keychain"],
    "servilletero": ["servilletero","servilleta"],
    "posavasos":    ["posavasos","coaster"],
    "caja":         ["caja","cajita","estuche","box"],
    "tabla":        ["tabla","tablon","madera"],
    "sticker":      ["sticker","calcomanía","vinil recorte","vinil"],
    "senaletica":   ["señalética","señal","letrero","cartel"],
    "acrilico":     ["acrílico","acrilico"],
    "copa":         ["copa","caballito","cenicero","tarro","vidrio","cristal"],
    "lamina":       ["lámina","lamina","cuadro sublimado"],
    "mouse_pad":    ["mouse pad","mousepad","pad"],
    "azulejo":      ["azulejo","cerámica","talavera"],
    "rompecabezas": ["rompecabezas","puzzle","puzle"],
    "panialero":    ["pañalero","pañal","bolsa bebé"],
    "sublimado":    ["sublimado","sublimación","sublimacion"],
}

def detectar_categoria_foto(texto: str) -> Optional[str]:
    t = (texto or "").lower()
    for cat, kws in CATEGORIA_KEYWORDS_FB.items():
        if any(k in t for k in kws):
            return cat
    return None

async def send_meta_message(page_token: str, recipient_id: str, texto: str) -> bool:
    try:
        async with httpx.AsyncClient(timeout=12) as client:
            r = await client.post(
                "https://graph.facebook.com/v18.0/me/messages",
                params={"access_token": page_token},
                json={"recipient": {"id": recipient_id}, "message": {"text": texto}}
            )
            return r.status_code == 200
    except Exception as e:
        log.error(f"send_meta_message: {e}")
        return False

async def procesar_mensaje_meta(cliente: dict, config: dict, sender_id: str, texto: str, canal: str):
    """Procesa un mensaje de FB Messenger o Instagram y genera/envía respuesta."""
    cid = cliente["id"]
    page_token = cliente["fb_page_token"] if canal == "messenger" else cliente["ig_token"]
    if not page_token:
        return

    db = get_db()
    try:
        # Verificar licencia
        from datetime import date as _date
        venc = cliente.get("fecha_vencimiento") or ""
        if venc and venc < str(_date.today()):
            await send_meta_message(page_token, sender_id,
                "El servicio de asistente automático está suspendido temporalmente.")
            return

        config_dict = dict(config)
        config_dict["cliente_id"] = cid
        chat_id = f"{canal}_{sender_id}"

        # Historial
        conv = db.execute("SELECT * FROM conversaciones WHERE cliente_id=? AND chat_id=?",
                          (cid, chat_id)).fetchone()
        historial = json.loads(conv["historial"]) if conv else []
        historial.append({"rol": "user", "texto": texto})

        # IA
        respuesta_raw = await generar_respuesta(config_dict, historial, texto)
        respuesta_visible, acciones = extraer_acciones(respuesta_raw)
        historial.append({"rol": "assistant", "texto": respuesta_visible})
        if len(historial) > 20:
            historial = historial[-20:]

        if conv:
            db.execute("UPDATE conversaciones SET historial=?,ultima_actividad=datetime('now') WHERE cliente_id=? AND chat_id=?",
                       (json.dumps(historial), cid, chat_id))
        else:
            db.execute("INSERT INTO conversaciones (cliente_id,chat_id,historial) VALUES (?,?,?)",
                       (cid, chat_id, json.dumps(historial)))

        db.execute("INSERT INTO mensajes (cliente_id,chat_id,direccion,texto) VALUES (?,?,?,?)",
                   (cid, chat_id, "in", texto))
        db.execute("INSERT INTO mensajes (cliente_id,chat_id,direccion,texto) VALUES (?,?,?,?)",
                   (cid, chat_id, "out", respuesta_visible))
        db.commit()

        await send_meta_message(page_token, sender_id, respuesta_visible)

        for accion in acciones:
            msgs_extra = await ejecutar_accion(accion, dict(cliente), config_dict, chat_id, db)
            for msg in msgs_extra:
                await send_meta_message(page_token, sender_id, msg)

    except Exception as e:
        log.error(f"procesar_mensaje_meta: {e}")
    finally:
        db.close()

@app.get("/webhook/meta")
async def meta_verify(request: Request):
    p = request.query_params
    if p.get("hub.mode") == "subscribe" and p.get("hub.verify_token") == META_VERIFY_TOKEN:
        return PlainTextResponse(p.get("hub.challenge", "OK"))
    raise HTTPException(403, "Verify token incorrecto")

@app.post("/webhook/meta")
async def meta_webhook(request: Request):
    body = await request.json()
    obj  = body.get("object", "")

    for entry in body.get("entry", []):
        page_id = entry.get("id", "")
        for ev in entry.get("messaging", []):
            sender_id = ev.get("sender", {}).get("id", "")
            if not sender_id or sender_id == page_id:
                continue
            msg  = ev.get("message", {})
            texto = msg.get("text", "")
            if not texto or msg.get("is_echo"):
                continue

            db = get_db()
            if obj == "instagram":
                canal   = "instagram"
                cliente = db.execute("SELECT * FROM clientes WHERE ig_account_id=? AND activo=1",
                                     (page_id,)).fetchone()
            else:
                # Facebook Messenger (puede incluir IG si cuenta conectada al Page)
                canal   = "messenger"
                cliente = db.execute("SELECT * FROM clientes WHERE fb_page_id=? AND activo=1",
                                     (page_id,)).fetchone()
                if not cliente:
                    # Intento IG account conectado como Page
                    cliente = db.execute("SELECT * FROM clientes WHERE ig_account_id=? AND activo=1",
                                         (page_id,)).fetchone()
                    if cliente:
                        canal = "instagram"

            if not cliente:
                db.close()
                continue

            config = db.execute("SELECT * FROM config_bot WHERE cliente_id=?",
                                 (cliente["id"],)).fetchone()
            db.close()
            if not config:
                continue

            # Verificar que el canal esté activo
            cfg = dict(config)
            if canal == "messenger" and not cfg.get("fb_activo", 0):
                continue
            if canal == "instagram" and not cfg.get("ig_activo", 0):
                continue

            asyncio.create_task(
                procesar_mensaje_meta(dict(cliente), cfg, sender_id, texto, canal)
            )

    return JSONResponse({"ok": True}, status_code=200)

# ── Sync de fotos desde Facebook ──────────────────────────────────────────────
async def _descargar_foto(url: str, dest: Path) -> bool:
    try:
        async with httpx.AsyncClient(timeout=20, follow_redirects=True) as client:
            r = await client.get(url)
            if r.status_code == 200 and "image" in r.headers.get("content-type", ""):
                dest.write_bytes(r.content)
                return True
    except Exception as e:
        log.error(f"_descargar_foto {url}: {e}")
    return False

@app.post("/api/clientes/{cid}/sync-fotos-fb")
async def sync_fotos_fb(cid: int, key: str = ""):
    check_admin(key)
    db = get_db()
    c = db.execute("SELECT * FROM clientes WHERE id=?", (cid,)).fetchone()
    db.close()
    if not c:
        raise HTTPException(404)
    page_id    = c["fb_page_id"]
    page_token = c["fb_page_token"]
    if not page_id or not page_token:
        return {"ok": False, "msg": "fb_page_id y fb_page_token requeridos"}

    folder   = carpeta_de(cid) or carpeta_cliente(cid, c["nombre_negocio"])
    prod_dir = folder / "productos"
    prod_dir.mkdir(exist_ok=True)

    descargadas, omitidas, errores = 0, 0, 0
    after = None
    while True:
        params = {
            "fields": "message,full_picture",
            "limit":  "50",
            "access_token": page_token,
        }
        if after:
            params["after"] = after
        try:
            async with httpx.AsyncClient(timeout=20) as client:
                r = await client.get(f"https://graph.facebook.com/v18.0/{page_id}/posts", params=params)
            data = r.json()
        except Exception as e:
            return {"ok": False, "msg": str(e)}

        if "error" in data:
            return {"ok": False, "msg": data["error"].get("message", str(data["error"]))}

        for post in data.get("data", []):
            img_url = post.get("full_picture", "")
            caption = post.get("message", "")
            if not img_url:
                continue
            cat = detectar_categoria_foto(caption)
            if not cat:
                omitidas += 1
                continue
            existentes = [f for f in prod_dir.iterdir() if f.stem.lower().startswith(cat)]
            num  = len(existentes) + 1
            dest = prod_dir / f"{cat}_{num:02d}.jpg"
            if not dest.exists():
                ok = await _descargar_foto(img_url, dest)
                if ok:
                    descargadas += 1
                else:
                    errores += 1
            else:
                omitidas += 1

        cursor = data.get("paging", {}).get("cursors", {}).get("after")
        if not cursor or not data.get("paging", {}).get("next"):
            break
        after = cursor

    return {"ok": True, "descargadas": descargadas, "omitidas": omitidas, "errores": errores}

@app.post("/api/clientes/{cid}/sync-fotos-ig")
async def sync_fotos_ig(cid: int, key: str = ""):
    check_admin(key)
    db = get_db()
    c = db.execute("SELECT * FROM clientes WHERE id=?", (cid,)).fetchone()
    db.close()
    if not c:
        raise HTTPException(404)
    ig_token = c["ig_token"]
    if not ig_token:
        return {"ok": False, "msg": "ig_token requerido"}

    folder   = carpeta_de(cid) or carpeta_cliente(cid, c["nombre_negocio"])
    prod_dir = folder / "productos"
    prod_dir.mkdir(exist_ok=True)

    descargadas, omitidas, errores = 0, 0, 0
    after = None
    while True:
        params = {
            "fields": "caption,media_type,media_url,thumbnail_url",
            "limit":  "50",
            "access_token": ig_token,
        }
        if after:
            params["after"] = after
        try:
            async with httpx.AsyncClient(timeout=20) as client:
                r = await client.get("https://graph.facebook.com/v18.0/me/media", params=params)
            data = r.json()
        except Exception as e:
            return {"ok": False, "msg": str(e)}

        if "error" in data:
            return {"ok": False, "msg": data["error"].get("message", str(data["error"]))}

        for media in data.get("data", []):
            mtype   = media.get("media_type", "")
            caption = media.get("caption", "")
            img_url = media.get("media_url") or media.get("thumbnail_url", "")
            if mtype == "VIDEO":
                img_url = media.get("thumbnail_url", "")
            if not img_url:
                continue
            cat = detectar_categoria_foto(caption)
            if not cat:
                omitidas += 1
                continue
            existentes = [f for f in prod_dir.iterdir() if f.stem.lower().startswith(cat)]
            num  = len(existentes) + 1
            dest = prod_dir / f"{cat}_{num:02d}.jpg"
            if not dest.exists():
                ok = await _descargar_foto(img_url, dest)
                if ok:
                    descargadas += 1
                else:
                    errores += 1
            else:
                omitidas += 1

        cursor = data.get("paging", {}).get("cursors", {}).get("after")
        if not cursor or not data.get("paging", {}).get("next"):
            break
        after = cursor

    return {"ok": True, "descargadas": descargadas, "omitidas": omitidas, "errores": errores}

@app.put("/api/clientes/{cid}/redes")
async def actualizar_redes(cid: int, request: Request, key: str = ""):
    """Guarda FB Page ID/Token e IG Account ID/Token del cliente."""
    check_admin(key)
    body = await request.json()
    db   = get_db()
    sets, vals = [], []
    for campo in ("fb_page_id", "fb_page_token", "ig_account_id", "ig_token"):
        if campo in body:
            sets.append(f"{campo}=?")
            vals.append(body[campo])
    if sets:
        db.execute(f"UPDATE clientes SET {','.join(sets)} WHERE id=?", vals + [cid])
    for campo in ("fb_activo", "ig_activo"):
        if campo in body:
            db.execute(f"UPDATE config_bot SET {campo}=? WHERE cliente_id=?", (body[campo], cid))
    db.commit()
    db.close()
    return {"ok": True}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("server:app", host="0.0.0.0", port=PORT, reload=False)
