@echo off
title BotWA SaaS — Simplex
color 0A
cd /d C:\chatbot_saas

echo.
echo  =========================================
echo   BOT WA SAAS — BY SIMPLEX  puerto 8005
echo  =========================================
echo.

:: Crear carpeta logs si no existe
if not exist logs mkdir logs

:: Arrancar servidor en background
echo  [1/2] Iniciando servidor...
start /min cmd /c "python server.py > logs\server.log 2>&1"
timeout /t 3 /nobreak > nul

:: Arrancar ngrok con dominio fijo
echo  [2/2] Iniciando ngrok...
start /min cmd /c "ngrok http 8005 --domain=enrique-slaty-afton.ngrok-free.dev > logs\ngrok.log 2>&1"
timeout /t 4 /nobreak > nul

echo.
echo  Servidor : http://localhost:8005/admin
echo  Publico  : https://enrique-slaty-afton.ngrok-free.dev
echo  Webhook  : https://enrique-slaty-afton.ngrok-free.dev/webhook/{ID_CLIENTE}
echo.
start http://localhost:8005/admin
