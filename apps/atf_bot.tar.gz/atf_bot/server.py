"""
ATF Bot — Actualiza Tus Faros
WhatsApp + Web + Social + MercadoLibre
Puerto 8010
"""
import os, json, asyncio, logging, httpx
from datetime import datetime
from pathlib import Path
from dotenv import load_dotenv
from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from openai import OpenAI

load_dotenv(Path(__file__).parent / ".env")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("ATF")

# ── Credenciales ──────────────────────────────────────────────────────────────
GROQ_KEY        = os.getenv("GROQ_API_KEY", "")
ZAI_KEY         = os.getenv("ZAI_API_KEY", "")
GREEN_INSTANCE  = os.getenv("GREEN_INSTANCE", "")
GREEN_TOKEN     = os.getenv("GREEN_TOKEN", "")
GREEN_SERVER    = os.getenv("GREEN_SERVER", "7103")
ATF_PHONE       = os.getenv("ATF_PHONE", "3326148674")
MELI_TOKEN_FILE = Path(__file__).parent / "data" / "meli_token.json"

CATALOGO_PATH = Path(__file__).parent.parent / "NEXUS_v3_NEW" / "data" / "catalogo_atf.json"

# ── Cargar catálogo ───────────────────────────────────────────────────────────
def _load_catalog() -> dict:
    try:
        return json.loads(CATALOGO_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}

CATALOGO = _load_catalog()

# ── System prompt ATF ─────────────────────────────────────────────────────────
def _build_system_prompt() -> str:
    prods = CATALOGO.get("productos", {})
    lineas = []
    for cod, p in prods.items():
        lineas.append(f"• {p['nombre']} — ${p['precio_publico']:,} MXN — {p.get('descripcion_corta','')}")

    return f"""Eres el asistente de ventas de ATF (Actualiza Tus Faros), negocio de retrofit de faros en Guadalajara, Jalisco.

PRODUCTOS DISPONIBLES (NUNCA menciones precio distribuidor):
{chr(10).join(lineas)}

ENVÍOS: Enviamos a toda la República. El cliente elige paquetería. El costo de envío lo paga el comprador.
MERCADOLIBRE: Vendemos en ML. La comisión de ML la paga el comprador (está incluida en el precio publicado).
WHATSAPP: {ATF_PHONE}
INSTALACIÓN: Solo en Guadalajara. Foráneos reciben el kit y lo instalan con instalador certificado CanbusFix.

REGLAS:
- Responde en español mexicano, tono amigable y profesional.
- Si preguntan por precio, da el precio público directamente.
- Si preguntan compatibilidad, pide marca/modelo/año del vehículo.
- Cierra siempre con el número de WhatsApp para cotización o pedido.
- Máximo 3 párrafos cortos. Sin markdown ni asteriscos en WhatsApp.
- Nunca reveles el precio distribuidor.
"""

SYSTEM_PROMPT = _build_system_prompt()

# ── IA (Groq → Z.ai → local) ──────────────────────────────────────────────────
async def ask_ai(user_msg: str, history: list[dict] | None = None) -> str:
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    if history:
        messages.extend(history[-6:])  # últimas 3 rondas
    messages.append({"role": "user", "content": user_msg})

    # Groq primero
    if GROQ_KEY:
        try:
            from groq import Groq
            loop = asyncio.get_event_loop()
            client = Groq(api_key=GROQ_KEY, timeout=20)
            resp = await loop.run_in_executor(None, lambda: client.chat.completions.create(
                model="llama-3.1-8b-instant", messages=messages, max_tokens=512, temperature=0.7
            ))
            return resp.choices[0].message.content
        except Exception as e:
            log.warning("Groq fallo: %s", e)

    # Z.ai fallback
    if ZAI_KEY:
        try:
            loop = asyncio.get_event_loop()
            client = OpenAI(api_key=ZAI_KEY, base_url="https://open.bigmodel.cn/api/paas/v4/", timeout=20)
            resp = await loop.run_in_executor(None, lambda: client.chat.completions.create(
                model="glm-4-flash", messages=messages, max_tokens=512, temperature=0.7
            ))
            return resp.choices[0].message.content
        except Exception as e:
            log.warning("Z.ai fallo: %s", e)

    return f"Gracias por tu mensaje. Para cotización inmediata escríbenos al {ATF_PHONE}."

# ── Green API helpers ──────────────────────────────────────────────────────────
GREEN_BASE = f"https://{GREEN_SERVER}.api.greenapi.com/waInstance{GREEN_INSTANCE}" if GREEN_INSTANCE else ""

async def send_wa(to_number: str, text: str):
    if not GREEN_INSTANCE or not GREEN_TOKEN:
        log.warning("Green API no configurado")
        return
    url = f"{GREEN_BASE}/sendMessage/{GREEN_TOKEN}"
    payload = {"chatId": f"{to_number}@c.us", "message": text}
    async with httpx.AsyncClient(timeout=15) as c:
        try:
            await c.post(url, json=payload)
        except Exception as e:
            log.error("sendMessage error: %s", e)

# ── Sesiones WA (memoria por número) ──────────────────────────────────────────
_sessions: dict[str, list[dict]] = {}

def _get_history(phone: str) -> list[dict]:
    return _sessions.setdefault(phone, [])

def _save_to_history(phone: str, role: str, content: str):
    h = _sessions.setdefault(phone, [])
    h.append({"role": role, "content": content})
    if len(h) > 20:
        _sessions[phone] = h[-20:]

# ── App ───────────────────────────────────────────────────────────────────────
app = FastAPI(title="ATF Bot")

WEB_DIR = Path(__file__).parent / "web"
if WEB_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(WEB_DIR)), name="static")

# ── Webhook Green API ──────────────────────────────────────────────────────────
@app.post("/wa/webhook")
async def wa_webhook(request: Request):
    try:
        data = await request.json()
    except Exception:
        return JSONResponse({"ok": False})

    msg_type = data.get("typeWebhook", "")
    if msg_type != "incomingMessageReceived":
        return JSONResponse({"ok": True})

    sender_data = data.get("senderData", {})
    from_phone  = sender_data.get("sender", "").replace("@c.us", "")
    msg_data    = data.get("messageData", {})
    text        = msg_data.get("textMessageData", {}).get("textMessage", "").strip()

    if not text or not from_phone:
        return JSONResponse({"ok": True})

    log.info("WA de %s: %s", from_phone, text[:80])

    history = _get_history(from_phone)
    _save_to_history(from_phone, "user", text)

    reply = await ask_ai(text, history)
    _save_to_history(from_phone, "assistant", reply)

    await send_wa(from_phone, reply)
    log.info("Respuesta enviada a %s", from_phone)
    return JSONResponse({"ok": True})

# ── API: probar bot ───────────────────────────────────────────────────────────
@app.post("/api/chat")
async def api_chat(request: Request):
    body = await request.json()
    msg = body.get("mensaje", "")
    tel = body.get("telefono", "test")
    history = _get_history(tel)
    _save_to_history(tel, "user", msg)
    reply = await ask_ai(msg, history)
    _save_to_history(tel, "assistant", reply)
    return JSONResponse({"respuesta": reply})

# ── API: catálogo ─────────────────────────────────────────────────────────────
@app.get("/api/catalogo")
async def api_catalogo():
    c = _load_catalog()
    productos = []
    for cod, p in c.get("productos", {}).items():
        productos.append({
            "codigo":     cod,
            "nombre":     p["nombre"],
            "precio":     p["precio_publico"],
            "specs":      p.get("specs", {}),
            "descripcion": p.get("descripcion_corta", ""),
            "badge":      p.get("badge", ""),
            "destacado":  p.get("destacado", False),
        })
    return JSONResponse({"productos": productos, "envios": c.get("envios", "")})

# ── API: publicar social (trigger manual o cron) ──────────────────────────────
@app.post("/api/publicar")
async def api_publicar():
    import subprocess, sys
    script = Path(__file__).parent.parent / "NEXUS_v3_NEW" / "atf_social_manager.py"
    if not script.exists():
        return JSONResponse({"error": "script no encontrado"}, status_code=404)
    proc = subprocess.Popen(
        [sys.executable, str(script), "diario"],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE
    )
    return JSONResponse({"ok": True, "pid": proc.pid, "mensaje": "Publicación iniciada"})

# ── Página principal ──────────────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
async def index():
    html_file = WEB_DIR / "index.html"
    if html_file.exists():
        return HTMLResponse(html_file.read_text(encoding="utf-8"))
    return HTMLResponse("<h1>ATF Bot activo</h1>")

@app.get("/health")
async def health():
    return {"status": "ok", "ts": datetime.now().isoformat(), "ia": "Groq+Z.ai"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("server:app", host="0.0.0.0", port=8010, reload=False)
