@echo off
title ATF Bot — Puerto 8010
cd /d C:\atf_bot
echo Iniciando ATF Bot en http://localhost:8010
start "" "http://localhost:8010"
python -m uvicorn server:app --host 0.0.0.0 --port 8010
pause
